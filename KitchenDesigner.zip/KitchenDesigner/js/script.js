//var dataurl = "https://lab.pikcells.com/code-exercise/data.json"; // Link to configuration data.
var dataurl = 'index.php'; // Link to local json file. This one does not shuffle the layerimages array.
var xhr = new XMLHttpRequest();
var imgurl, data, selitem0=0,selitem2=0;
xhr.open('GET', dataurl, true);

//Function to fetch configuration data.
xhr.onreadystatechange = function() {
    
 if (xhr.readyState == 4 && xhr.status == 200) {
    
   var x, y,txt;
   data = JSON.parse(xhr.responseText);
     

     
   imgurl = 'https://s3.eu-west-2.amazonaws.com/pikcells-lab/code-exercise/images/';
   var i,j,l;
   for (x in data.layers) {
       
    data.layers[x].items.sort(function (a, b) {
    return a.order - b.order;
    });
       
        i = data.layers[x].order+1;
        txt = "";
        txt += '<div class="grid-container">';
        l = i-1;
        j=0;
    
       for (y in data.layers[x].items) {

        txt += '<div class="grid-item" onclick="selimage('+l+','+j+')"><img src="'+imgurl+data.layers[x].items[y].imgSrc+'" alt="'+data.layers[x].items[y].name+'" style="width:100%"><p>'+data.layers[x].items[y].order+" - "+data.layers[x].items[y].name+'</p></div>';
          j++;
        }
       
     txt += '</div>';

     document.getElementById("layer"+i).innerHTML = txt;
     selimage(l, data.default_configuration[l]);
     
     }
 }
};

xhr.send();

//Function to draw selected image on canvas.
  
function selimage(layer, itemnum){
    var img;
    
    if(layer == '0'){
       selitem0 = itemnum;
       }
    
    if(layer == '2'){
       selitem2 = itemnum;
       }
    
    var c = document.getElementById("mycanvas");
    var ctx = c.getContext("2d");
    
    img = new Image();
    img.onload = function(){
    ctx.drawImage(this, 0, 0, this.width,    this.height,    
     0, 0, c.width, c.height);
    };
    
    if(layer ==  '1'){
        
    img.src = imgurl+data.layers[0].items[selitem0].imgSrc;
    ctx.drawImage(img, 0, 0, img.width,    img.height,  
     0, 0, c.width, c.height);
        
    img.src = imgurl+data.layers[2].items[selitem2].imgSrc;
    ctx.drawImage(img, 0, 0, img.width,    img.height, 
     0, 0, c.width, c.height);
        
     }
    
    img.src = imgurl+data.layers[layer].items[itemnum].imgSrc;
    activeitem(layer, itemnum);
}

//Function to highlight currently selected item.
            
 function activeitem(layer, itemnum){
     
    layer++;
     
    var header = document.getElementById("layer"+layer);
    var grid = header.getElementsByClassName("grid-container");
    var items = grid[0].getElementsByClassName("grid-item");
    var current = grid[0].getElementsByClassName("active");
     
    if(current.length > 0){
    current[0].className = current[0].className.replace(" active", "");
    }

    items[itemnum].className += " active";
  }
 