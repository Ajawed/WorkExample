<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@players')->name('players');
Route::get('/leaderboard', 'PagesController@leaderboard')->name('leaderboard');
Route::get('/profile/{player_id}', 'PagesController@profile')->name('profile');
Route::get('/newplayer', 'PagesController@newplayer')->name('newplayer');
Route::get('/editplayer/{player_id}', 'PagesController@editplayer')->name('editplayer');
Route::post('/createplayer', 'PagesController@newplayer')->name('createplayer');
Route::post('/updateplayer/{player_id}', 'PagesController@update')->name('updateplayer');
Route::get('/delplayer/{player_id}', 'PagesController@delplayer')->name('delplayer');