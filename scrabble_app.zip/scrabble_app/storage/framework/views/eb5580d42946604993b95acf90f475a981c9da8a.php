<div id="id01" class="modal">
      <div class="container modal-content">

        <h4>Do You Really Want to Delete This Player?</h4>
  
        <div class="clearfix">
        <a href="<?php echo e(route('delplayer', ['player_id' => $player_id ])); ?>"><button class="yesbtn">Yes</button></a>
          <button onclick="cancel()" class="cancelbtn">Cancel</button>
        </div>
      </div>
  </div>