
<div id="id01" class="modal">
                
    <form class="modal-content animate" action="/action_page.php">
      <div class="container">
          <div class="close-cont">
          <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
          </div>
              
          <label><b>First Name</b></label>
              
        <input type="text"  placeholder="Enter Fname" name="email" required>
          
        <label><b>Nickname</b></label>
              
        <input type="text" placeholder="Enter Nickname" name="psw-repeat" required>
               
  
        <label><b>Surname</b></label>
        <input type="text" placeholder="Enter Password" name="psw" required>
          
        <label><b>Email</b></label>
        <input type="text" placeholder="Enter Email" name="psw-repeat" required>
          
          
        <label><b>Phone Number</b></label>
        <input type="text" placeholder="Phone Number" name="psw-repeat" required>
  
  
        <div class="clearfix">
          <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
          <button type="submit" class="signupbtn">Save</button>
        </div>
      </div>
    </form>
  </div>