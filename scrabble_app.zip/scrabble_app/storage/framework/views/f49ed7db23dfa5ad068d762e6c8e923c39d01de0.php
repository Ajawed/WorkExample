<?php $titl = 'Players' ?>


<?php $__env->startSection('content'); ?>
<main>
            
    <h1>Players</h1>
            
         <a href="<?php echo e(route('newplayer')); ?>" ><div class="button" style="color:white" 
          style="text-decoration: none">ADD NEW PLAYER</div></a>
            
            <input type="search"  onkeyup="filtersearch()" id="myInput" placeholder="Search Players..." name="search">

            <table>
                <thead>
            <tr>
              <th>Player Name</th>
              <th>Nickname</th>    
              <th>Email</th>
              <th>Action</th>
            </tr>
                </thead>
                
                <tbody id="myTable">
              <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td>
                  <a  href="<?php echo e(route('profile', ['player_id' => $player->id ])); ?>"><?php echo e($player->title); ?>. <?php echo e($player->firstname); ?> <?php echo e($player->surname); ?></a>
                </td>
                <td><?php echo e($player->nickname); ?></td>
                <td><?php echo e($player->email); ?></td>
                <td>
                  <a href="<?php echo e(route('editplayer', ['player_id' => $player->id ])); ?>">EDIT</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
        </table>
 
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>