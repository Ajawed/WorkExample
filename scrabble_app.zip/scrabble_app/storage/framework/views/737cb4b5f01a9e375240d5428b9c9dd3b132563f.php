<?php $titl = 'Profile'; ?>



<?php $__env->startSection('content'); ?>

<?php echo $__env->make('layout.warning', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main>  
        <div>
        <h1 style="text-align: center;"><?php echo e($nickname); ?></h1>
        <h3 style="text-align: center;">Member Since: <?php echo e($date); ?> </h3>    
        </div>   
      <div > 
        <table style="width: 60%; margin-left: 20%; ">
       <tr>
       <th>Player Name:</th>
       <td><?php echo e($title); ?>. <?php echo e($firstname); ?> <?php echo e($surname); ?></td>
       </tr>
       <tr>
       <th>Games Won:</th>
           <td><?php echo e($gameswon); ?></td>
       </tr>
       <tr>
       <th>Games Lost:</th>
       <td><?php echo e($gameslost); ?></td>
       </tr>
            <tr>

       <th>Average Score:</th>
       <?php if($avarage != null): ?>
       <td><?php echo e($avarage->avg); ?></td>
       <?php else: ?>
       <td>0</td>
       <?php endif; ?>

       </tr>
            <tr>
       <th>Highest Score:</th>

        <?php if($highscore != null): ?>
        <?php if($oponent == null): ?>
       <td><?php echo e($highscore->score); ?> VS Deleted PLayer ON <?php echo e($highscore->created_at); ?></td>
        <?php else: ?>
        <td><?php echo e($highscore->score); ?> VS <a href="<?php echo e(route('profile', ['player_id' => $oponent->playerid ])); ?>">
          <?php echo e($oponent->nickname); ?></a> ON <?php echo e($highscore->created_at); ?></td>
        <?php endif; ?>
        <?php else: ?>
        <td>Haven't Played A Game</td>
        <?php endif; ?>

       </tr>
       </table>
            </div>
                      
          <div style="text-align: center; margin-top: 10px;">
           <a class="link" href="<?php echo e(route('editplayer', ['player_id' => $player_id ])); ?>" 
            style="text-decoration: none" >EDIT Details</a>
            <a class="link" onclick="confirm()">Delete Player</a>
          </div> 
        </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>