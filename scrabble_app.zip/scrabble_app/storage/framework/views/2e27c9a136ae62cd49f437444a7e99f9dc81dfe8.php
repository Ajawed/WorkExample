<?php $__env->startSection('content'); ?>

<main>
            
    <h1>Players</h1>
            
         <button onclick="document.getElementById('id01').style.display='block'" style="width:auto;">Add New Player</button> 
            
            <input type="search"  onkeyup="filtersearch()" id="myInput" placeholder="Search Players..." name="search">
            
            <?php echo $__env->make('forms.newplayer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('forms.editplayer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <table>
                <thead>
            <tr>
              <th>Player Name</th>
              <th>Nickname</th>    
              <th>Email</th>
              <th>Action</th>
            </tr>
                </thead>
                
                <tbody id="myTable">
                <tr>
                <td>Shahid Afridi</td>
                <td>Shahid11</td>
                <td>Shahid11</td>
                <td>
                  <a  onclick="document.getElementById('id01').style.display='block'">EDIT</a>
                  <a  onclick="Remove()">Remove</a>
                </td>
              </tr>
                </tbody>
        </table>
 
        </main>
    
       <script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}

function filtersearch() {
  var input, filter, table, tr, td, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
    
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}
    function Remove() {
    var txt;
    if (confirm("Do You Really Want to Delete This Player") == true) {
        txt = "You pressed OK!";
    } else {
        txt = "You pressed Cancel!";
    }
    document.getElementById("demo").innerHTML = txt;
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>