<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title><?php echo e($titl); ?></title>
        <meta name="description" content="Search Engine For T20i Players and Teams">
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </head>
    <body>
           <main>
            <header>
                    <nav>
                     <a href="<?php echo e(route('players')); ?>"><img class="logo" src="<?php echo e(asset('imgs/logo.png')); ?>"></a>
                      <a href="<?php echo e(route('players')); ?>">Players</a>
                      <a href="<?php echo e(route('leaderboard')); ?>">Leader Board</a>
                  </nav>
              </header>

        <?php echo $__env->yieldContent('content'); ?>

           </main>
</body>
</html>