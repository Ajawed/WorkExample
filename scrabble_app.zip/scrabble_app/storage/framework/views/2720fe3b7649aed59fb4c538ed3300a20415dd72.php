<?php $titl = 'Leaderboard' ?>



<?php $__env->startSection('content'); ?>

<main>
        
        <h1>Leader Board</h1>
        
        <h5>Top 10 average scores from those members who have played at least 10 matches</h5>
        
</table>

<table>
  <thead>
<tr>
<th>Position</th>
<th>Player</th>    
<th>Average Scores</th>
</tr>
  </thead>
  
  <tbody id="myTable">
      <?php $pos = 0; ?>
<?php $__currentLoopData = $topplayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $pos++; ?> 
  <tr>
      <td><?php echo e($pos); ?></td>
  <td>
    <a  href="<?php echo e(route('profile', ['player_id' => $player->id ])); ?>"><?php echo e($player->nickname); ?></a>
  </td>
  <?php if($player->avg !=null): ?>
  <td><?php echo e($player->avg); ?></td>
  <?php else: ?>
  <td>0</td>
  <?php endif; ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>
        
        </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>