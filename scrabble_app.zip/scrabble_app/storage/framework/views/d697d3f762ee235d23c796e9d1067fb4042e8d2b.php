<?php
  if( $modify == 1 ){
  $titl = 'Modify';
  }
  else{
    $titl = 'Add New Player';
  }
?>


<?php $__env->startSection('content'); ?>
<div >
      <div>
        <h4><?php echo e($modify == 1 ? 'Edit Player' : 'New Player'); ?></h4>
        <form action="<?php echo e($modify == 1 ? route('updateplayer', [ 'player_id' => $player_id ]) : route('createplayer')); ?>" method="post">
           <div>
            <label>Title</label>
            <select name="title">
            <?php $__currentLoopData = $titles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($title); ?>" ><?php echo e($title); ?>.</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
          </div> 
          <div>
            <label>Nickname</label>
            <input name="nickname" type="text" value="<?php echo e(old('nickname') ? old('nickname') : $nickname); ?>">
            <small class="error"><?php echo e($errors->first('nickname')); ?></small>
          </div>
          <div>
            <label>First Name</label>
            <input name="firstname" type="text" value="<?php echo e(old('firstname') ? old('firstname') : $firstname); ?>">
            <small class="error"><?php echo e($errors->first('firstname')); ?></small>
          </div>
          <div>
            <label>Surname</label>
            <input name="surname" type="text" value="<?php echo e(old('surname') ? old('surname') : $surname); ?>">
            <small class="error"><?php echo e($errors->first('surname')); ?></small>
          </div>
          <div>
            <label>Email</label>
            <input name="email" type="text" value="<?php echo e(old('email') ? old('email') : $email); ?>">
            <small class="error"><?php echo e($errors->first('email')); ?></small>
          </div>
          <div>
            <label>Phone</label>
            <input name="phone" type="text" value="<?php echo e(old('phone') ? old('phone') : $phone); ?>">
            <small class="error"><?php echo e($errors->first('phone')); ?></small>
          </div>
          <div>
            <label>Password</label>
            <input name="password" type="password">
            <small class="error"><?php echo e($errors->first('password')); ?></small>
          </div>
          <div>
            <input value="SAVE" class="button" type="submit">
          </div>
        </form>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>