<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Scores extends Model
{
    //
}
