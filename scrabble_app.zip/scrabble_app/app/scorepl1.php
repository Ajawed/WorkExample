<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class scorepl1 extends Model
{
    
}
