<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use DB;

class Player extends Model
{
    
public function getTopAvarages(){
        $topavgs = DB::select(
        DB::raw("SELECT * FROM players LEFT JOIN (SELECT playerid, AVG(Average) AS avg 
        FROM(SELECT playerid, AVG(score) AS Average FROM scorepl1s GROUP BY playerid 
        UNION SELECT playerid, AVG(score) AS Average FROM scorepl2s GROUP BY playerid) 
        AS result GROUP BY playerid) AS scores ON players.id = scores.playerid  
        ORDER BY `scores`.`avg`  DESC Limit 10"));

    return $topavgs;
}

public function getAvarage($player_id){
        $avg = DB::selectone(
        DB::raw("SELECT playerid, AVG(Average) AS avg 
        FROM(SELECT playerid, AVG(score) AS Average 
        FROM scorepl1s WHERE playerid = $player_id GROUP BY playerid 
        UNION 
        SELECT playerid, AVG(score) AS Average 
        FROM scorepl2s WHERE playerid = $player_id GROUP BY playerid) AS avgscore GROUP BY playerid
        LIMIT 1"));

    return $avg;
}

public function getHighscore($player_id){
        $score = DB::selectone(
        DB::raw("SELECT playerid, score, scorepl1s.gameid, games.location, games.created_at 
        FROM scorepl1s, games WHERE scorepl1s.playerid = $player_id AND games.gameid = scorepl1s.gameid
        UNION 
        SELECT playerid, score, scorepl2s.gameid, games.location, games.created_at 
        FROM scorepl2s, games WHERE scorepl2s.playerid = $player_id AND games.gameid = scorepl2s.gameid  
        ORDER BY `score`  DESC LIMIT 1"));

    return $score;
}

public function getOponent($player_id, $gameid){
        $oponent = DB::selectone(
        DB::raw("SELECT scorepl1s.playerid, players.nickname, scorepl1s.score
        FROM scorepl1s, players WHERE playerid != $player_id AND scorepl1s.playerid = players.id 
        AND scorepl1s.gameid = $gameid
        UNION 
        SELECT scorepl2s.playerid, players.nickname, scorepl2s.score 
        FROM scorepl2s, players WHERE playerid != $player_id 
        AND scorepl2s.playerid = players.id AND 
        scorepl2s.gameid = $gameid LIMIT 1"));

    return $oponent;
}

}
