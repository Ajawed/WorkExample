<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Title as Title;
use App\Player as Player;
use App\scorepl1 as scorepl1;
use App\scorepl2 as scorepl2;


class PagesController extends Controller
{
    public function __construct( Title $titles, Player $player, scorepl1 $scorepl1 , scorepl2 $scorepl2 )
    {
        $this->titles = $titles->all();
        $this->player = $player;
        $this->scorepl1 = $scorepl1;
        $this->scorepl2 = $scorepl2;

    }

    public function players(){

        $data = [];
        $data['players'] = $this->player->all();
        return view('pages.index', $data);
    }

    public function leaderboard(){

        $score1 = $this->scorepl1->all();
        $data = [];
        $data['topplayers'] = $this->player->getTopAvarages();

        return view('pages.leaderboard', $data);
    }

    public function profile($player_id)
    {
        
        $data = []; 
        $data['player_id'] = $player_id;
        $player_data = $this->player->find($player_id);
        $data['title'] = $player_data->title;
        $data['firstname'] = $player_data->firstname;
        $data['surname'] = $player_data->surname;
        $data['nickname'] = $player_data->nickname;
        $data['gameswon'] = $player_data->gameswon;
        $data['gameslost'] = $player_data->gameslost;
        $data['date'] = $player_data->created_at;
        $data['avarage'] = $this->player->getAvarage($player_id);
        $data['highscore'] = $this->player->getHighscore($player_id);
        if($data['highscore'] != null ){
        $gameid = $data['highscore']->gameid;

        $data['oponent'] = $this->player->getOponent($player_id, $gameid);
        }
        else{
        $data['oponent'] = null;
        }

        
        return view('pages.profile', $data);
    }

    public function editplayer($player_id)
    {

        $data = [];

        $data['titles'] = $this->titles;
        $data['modify'] = 1;
        $data['player_id'] = $player_id;
        $player_data = $this->player->find($player_id);
        $data['title'] = $player_data->title;
        $data['firstname'] = $player_data->firstname;
        $data['surname'] = $player_data->surname;
        $data['nickname'] = $player_data->nickname;
        $data['email'] = $player_data->email;
        $data['phone'] = $player_data->phone;
        
        return view('pages.form', $data);
    }

    public function update(Request $request, $player_id, Player $player )
    {
        $data = [];

        $data['title'] = $request->input('title');
        $data['nickname'] = $request->input('nickname');
        $data['firstname'] = $request->input('firstname');
        $data['surname'] = $request->input('surname');
        $data['email'] = $request->input('email');
        $data['phone'] = $request->input('phone');
        $data['password'] = $request->input('password');
        
        if( $request->isMethod('post') )
        {
            //dd($data);
            $this->validate(
                $request,
                [
                    'nickname' => 'required|min:6',
                    'firstname' => 'required',
                    'surname' => 'required',
                    'email' => 'required',
                    'phone' => 'required',
                    'password' => 'required|min:8',

                ]
            );

            $player_data = $this->player->find($player_id);

            $player_data->title = $request->input('title');
            $player_data->nickname = $request->input('nickname');
            $player_data->firstname = $request->input('firstname');
            $player_data->surname = $request->input('surname');
            $player_data->email = $request->input('email');
            $player_data->phone = $request->input('phone');
            $player_data->password = $request->input('password');

            $player_data->save();

            return redirect()->route('profile', ['player_id' => $player_id]);
        }

        return view('pages.form', $data);
    }

    public function newplayer(Request $request, Player $player )
    {

        $data = [];

        $data['title'] = $request->input('title');
        $data['nickname'] = $request->input('nickname');
        $data['firstname'] = $request->input('firstname');
        $data['surname'] = $request->input('surname');
        $data['email'] = $request->input('email');
        $data['phone'] = $request->input('phone');
        $data['password'] = $request->input('password');
        
        if( $request->isMethod('post') )
        {
            //dd($data);
            $this->validate(
                $request,
                [
                    'title' => 'required',
                    'nickname' => 'required|min:6',
                    'firstname' => 'required',
                    'surname' => 'required',
                    'email' => 'required',
                    'phone' => 'required',
                    'password' => 'required|min:8',

                ]
            );

            $player->insert($data);

            return redirect()->route('players');
        }

        $data['titles'] = $this->titles;
        $data['modify'] = 0;
        return view('pages.form', $data);
    }

    public function delplayer($player_id) {

      $this->player->find($player_id)->delete();
       
            return redirect()->route('players');
        }
}
