<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>{{ $titl }}</title>
        <meta name="description" content="Search Engine For T20i Players and Teams">
        <link rel="stylesheet" href="{{asset('css/app.css')}}">

        <script src="{{asset('js/app.js')}}"></script>
    </head>
    <body>
           <main>
            <header>
                    <nav>
                     <a href="{{ route('players') }}"><img class="logo" src="{{asset('imgs/logo.png')}}"></a>
                      <a href="{{ route('players') }}">Players</a>
                      <a href="{{ route('leaderboard') }}">Leader Board</a>
                  </nav>
              </header>

        @yield('content')

           </main>
</body>
</html>