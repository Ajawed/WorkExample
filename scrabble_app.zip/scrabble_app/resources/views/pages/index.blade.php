
<?php $titl = 'Players' ?>

@extends('layout.app')
@section('content')
<main>
            
    <h1>Players</h1>
            
         <a href="{{ route('newplayer') }}" ><div class="button" style="color:white" 
          style="text-decoration: none">ADD NEW PLAYER</div></a>
            
            <input type="search"  onkeyup="filtersearch()" id="myInput" placeholder="Search Players..." name="search">

            <table>
                <thead>
            <tr>
              <th>Player Name</th>
              <th>Nickname</th>    
              <th>Email</th>
              <th>Action</th>
            </tr>
                </thead>
                
                <tbody id="myTable">
              @foreach( $players as $player )
                <tr>
                <td>
                  <a  href="{{ route('profile', ['player_id' => $player->id ]) }}">{{ $player->title }}. {{ $player->firstname }} {{ $player->surname }}</a>
                </td>
                <td>{{ $player->nickname }}</td>
                <td>{{ $player->email }}</td>
                <td>
                  <a href="{{ route('editplayer', ['player_id' => $player->id ]) }}">EDIT</a>
                </td>
              </tr>
              @endforeach

                </tbody>
        </table>
 
        </main>

@endsection