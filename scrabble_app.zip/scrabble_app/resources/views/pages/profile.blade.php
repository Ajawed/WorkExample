<?php $titl = 'Profile'; ?>

@extends('layout.app')

@section('content')

@include('layout.warning')

<main>  
        <div>
        <h1 style="text-align: center;">{{ $nickname }}</h1>
        <h3 style="text-align: center;">Member Since: {{ $date }} </h3>    
        </div>   
      <div > 
        <table style="width: 60%; margin-left: 20%; ">
       <tr>
       <th>Player Name:</th>
       <td>{{ $title }}. {{ $firstname }} {{ $surname }}</td>
       </tr>
       <tr>
       <th>Games Won:</th>
           <td>{{$gameswon}}</td>
       </tr>
       <tr>
       <th>Games Lost:</th>
       <td>{{$gameslost}}</td>
       </tr>
            <tr>

       <th>Average Score:</th>
       @if($avarage != null)
       <td>{{ $avarage->avg }}</td>
       @else
       <td>0</td>
       @endif

       </tr>
            <tr>
       <th>Highest Score:</th>

        @if($highscore != null)
        @if($oponent == null)
       <td>{{ $highscore->score }} VS Deleted PLayer ON {{ $highscore->created_at }}</td>
        @else
        <td>{{ $highscore->score }} VS <a href="{{ route('profile', ['player_id' => $oponent->playerid ]) }}">
          {{$oponent->nickname}}</a> ON {{ $highscore->created_at }}</td>
        @endif
        @else
        <td>Haven't Played A Game</td>
        @endif

       </tr>
       </table>
            </div>
                      
          <div style="text-align: center; margin-top: 10px;">
           <a class="link" href="{{ route('editplayer', ['player_id' => $player_id ]) }}" 
            style="text-decoration: none" >EDIT Details</a>
            <a class="link" onclick="confirm()">Delete Player</a>
          </div> 
        </main>
@endsection