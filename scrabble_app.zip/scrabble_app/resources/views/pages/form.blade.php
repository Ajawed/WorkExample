<?php
  if( $modify == 1 ){
  $titl = 'Modify';
  }
  else{
    $titl = 'Add New Player';
  }
?>

@extends('layout.app')
@section('content')
<div >
      <div>
        <h4>{{ $modify == 1 ? 'Edit Player' : 'New Player' }}</h4>
        <form action="{{ $modify == 1 ? route('updateplayer', [ 'player_id' => $player_id ]) : route('createplayer') }}" method="post">
           <div>
            <label>Title</label>
            <select name="title">
            @foreach( $titles as $title )
                          <option value="{{ $title }}" >{{ $title }}.</option>
            @endforeach
                        </select>
          </div> 
          <div>
            <label>Nickname</label>
            <input name="nickname" type="text" value="{{ old('nickname') ? old('nickname') : $nickname }}">
            <small class="error">{{$errors->first('nickname')}}</small>
          </div>
          <div>
            <label>First Name</label>
            <input name="firstname" type="text" value="{{ old('firstname') ? old('firstname') : $firstname }}">
            <small class="error">{{$errors->first('firstname')}}</small>
          </div>
          <div>
            <label>Surname</label>
            <input name="surname" type="text" value="{{ old('surname') ? old('surname') : $surname}}">
            <small class="error">{{$errors->first('surname')}}</small>
          </div>
          <div>
            <label>Email</label>
            <input name="email" type="text" value="{{ old('email') ? old('email') : $email }}">
            <small class="error">{{$errors->first('email')}}</small>
          </div>
          <div>
            <label>Phone</label>
            <input name="phone" type="text" value="{{ old('phone') ? old('phone') : $phone }}">
            <small class="error">{{$errors->first('phone')}}</small>
          </div>
          <div>
            <label>Password</label>
            <input name="password" type="password">
            <small class="error">{{$errors->first('password')}}</small>
          </div>
          <div>
            <input value="SAVE" class="button" type="submit">
          </div>
        </form>
      </div>
    </div>
@endsection