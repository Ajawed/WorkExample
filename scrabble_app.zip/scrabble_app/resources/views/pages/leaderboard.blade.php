<?php $titl = 'Leaderboard' ?>

@extends('layout.app')

@section('content')

<main>
        
        <h1>Leader Board</h1>
        
        <h5>Top 10 average scores from those members who have played at least 10 matches</h5>
        
</table>

<table>
  <thead>
<tr>
<th>Position</th>
<th>Player</th>    
<th>Average Scores</th>
</tr>
  </thead>
  
  <tbody id="myTable">
      <?php $pos = 0; ?>
@foreach( $topplayers as $player )
<?php $pos++; ?> 
  <tr>
      <td>{{ $pos }}</td>
  <td>
    <a  href="{{ route('profile', ['player_id' => $player->id ]) }}">{{ $player->nickname }}</a>
  </td>
  @if ($player->avg !=null)
  <td>{{ $player->avg }}</td>
  @else
  <td>0</td>
  @endif
</tr>
@endforeach
  </tbody>
</table>
        
        </main>

@endsection