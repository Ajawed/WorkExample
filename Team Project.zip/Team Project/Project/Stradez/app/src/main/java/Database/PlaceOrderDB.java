package Database;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.arslan.stradez.MyAccountActivity;
import com.example.arslan.stradez.OrderConfirmActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * PlaceOrderDB class used to place order for one item at a time
 * Created by Arslan on 03/03/2018.
 */

public class PlaceOrderDB extends AsyncTask<String, Void, String> {
    AlertDialog alertDialog;
    Context ctx;
    String usernam;
    String itemtitle;
    String itemid;

    public PlaceOrderDB(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPreExecute() {
    }

    @Override
    protected String doInBackground(String... params) {
        String urll = "https://selene.hud.ac.uk/kingsman/placeorder.php";
        String username = params[0];
        itemid = params[1];
        String qty = params[2];
        itemtitle = params[3];
        try {
            URL url = new URL(urll);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream OS = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(OS, "UTF-8"));
            String data = URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8") + "&" +
                    URLEncoder.encode("itemid", "UTF-8") + "=" + URLEncoder.encode(itemid, "UTF-8") + "&" +
                    URLEncoder.encode("qty", "UTF-8") + "=" + URLEncoder.encode(qty, "UTF-8");
            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();
            OS.close();
            InputStream IS = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS));
            String response = bufferedReader.readLine();
            bufferedReader.close();
            IS.close();
            httpURLConnection.connect();
            httpURLConnection.disconnect();
            return response;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected void onPostExecute(String result) {

    }
}
