package Database;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.arslan.stradez.HomeActivity;
import com.example.arslan.stradez.Login_RegisterActivity;
import com.example.arslan.stradez.MyAccountActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * AuthanticateDB class used to login, register and modify user details on the database
 * Created by Arslan on 07/01/2018.
 */
public class AuthanticateDB extends AsyncTask<String, Void, String> {
    AlertDialog loginDialog;
    AlertDialog regDialog;
    AlertDialog.Builder regsuccessdlg;
    Context ctx;
    String method;
    String usernam, activity = "";

    public AuthanticateDB(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPreExecute() {
        loginDialog = new AlertDialog.Builder(ctx).create();
        loginDialog.setTitle("Login Information");
        regDialog = new AlertDialog.Builder(ctx).create();
        regDialog.setTitle("Registeration Information");
        regsuccessdlg = new AlertDialog.Builder(ctx);
        regsuccessdlg.setTitle("Registeration Information");
    }

    @Override
    protected String doInBackground(String... params) {
        String reg_url = "https://selene.hud.ac.uk/kingsman/register.php";
        String login_url = "https://selene.hud.ac.uk/kingsman/login.php";
        method = params[0];
        String fname = null;
        String sname = null;
        String user_name = null;
        String email = null;
        String phnum = null;
        String user_pass = null;
        String login_name = params[1];
        usernam = login_name;
        String login_pass = params[2];
        activity = params[3];

        if (method.equals("modify")) {
            reg_url = "https://selene.hud.ac.uk/kingsman/updateuser.php";
            fname = params[1];
            sname = params[2];
            user_name = params[3];
            email = "";
            phnum = params[4];
            user_pass = params[5];
        } else if (method.equals("login")) {
            login_name = params[1];
            usernam = login_name;
            login_pass = params[2];
            activity = params[3];
        } else {
            fname = params[1];
            sname = params[2];
            user_name = params[3];
            email = params[4];
            phnum = params[5];
            user_pass = params[6];
        }
        if (method.equals("register") || method.contains("modify")) {

            try {
                URL url = new URL(reg_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream OS = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(OS, "UTF-8"));
                String data = URLEncoder.encode("first_name", "UTF-8") + "=" + URLEncoder.encode(fname, "UTF-8") + "&" +
                        URLEncoder.encode("sur_name", "UTF-8") + "=" + URLEncoder.encode(sname, "UTF-8") + "&" +
                        URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(user_name, "UTF-8") + "&" +
                        URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8") + "&" +
                        URLEncoder.encode("phone_number", "UTF-8") + "=" + URLEncoder.encode(phnum, "UTF-8") + "&" +
                        URLEncoder.encode("user_pass", "UTF-8") + "=" + URLEncoder.encode(user_pass, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                OS.close();
                InputStream IS = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS));
                String response = bufferedReader.readLine();
                bufferedReader.close();
                IS.close();
                httpURLConnection.connect();
                httpURLConnection.disconnect();
                return response;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (method.equals("login")) {
            try {
                URL url = new URL(login_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("login_name", "UTF-8") + "=" + URLEncoder.encode(login_name, "UTF-8") + "&" +
                        URLEncoder.encode("login_pass", "UTF-8") + "=" + URLEncoder.encode(login_pass, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String response = "";
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    response = response + line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
                return response;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    /**
     * After the ececution onPostExecute process the result
     * iff the method is login it saves the username in shared prefrence if the login was
     * successful and start activity was requested and requires login and it show error if it was not
     * successful
     * iff the method is register it show welcome message if the login wassuccessful
     * and it show error if it was not successful
     * iff the method is modify it call showResult method in MyAccount activity
     * and parse result
     *
     * @param result
     */
    @Override
    protected void onPostExecute(String result) {

        if (method.equals("login")) {
            if (result.contains("success")) {
                SharedPreferences sharedPref = ctx.getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("username", usernam);
                editor.apply();

                try {
                    Class<?> c = Class.forName(activity);
                    Intent myIntent = new Intent(ctx, c);
                    ctx.startActivity(myIntent);
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                loginDialog.setMessage(result);
                loginDialog.show();
            }

        }
        if (method.equals("register")) {

            if (result.contains("success")) {
                regsuccessdlg.setMessage("Thank You For Registering With Stradez");
                regsuccessdlg.setPositiveButton("Login Now", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        Intent myIntent = new Intent(ctx, Login_RegisterActivity.class);
                        myIntent.putExtra("activity", "com.example.arslan.stradez.MyAccountActivity");
                        ctx.startActivity(myIntent);
                    }
                });
                regsuccessdlg.setNegativeButton("Not Now", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });
                regsuccessdlg.show();
            } else {
                regDialog.setMessage(result);
                regDialog.show();
            }
        }
        if (method.equals("modify")) {
            ((MyAccountActivity) ctx).showResult(result);
        }

    }

}

