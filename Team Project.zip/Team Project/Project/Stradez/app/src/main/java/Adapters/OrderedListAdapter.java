package Adapters;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.example.arslan.stradez.PurchaseHistoryActivity;
import com.example.arslan.stradez.R;
import com.example.arslan.stradez.ItemActivity;
import com.squareup.picasso.Picasso;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import Database.BuyerDB;

/**
 * OrderedListAdapter class is used to adapt the cursor in the Listview.
 * <p>
 * Created by Arslan on 18/02/2018.
 */

public class OrderedListAdapter extends SimpleCursorAdapter {

    private Cursor c;
    private Context context;

    /**
     * Constructer for OrderedListAdapter
     *
     * @param context
     * @param layout
     * @param c
     * @param from
     * @param to
     * @param flags
     */

    public OrderedListAdapter(Context context, int layout, Cursor c, String[] from, int[] to, int flags) {
        super(context, layout, c, from, to, flags);
        this.c = c;
        this.context = context;
    }

    /**
     * this method set values of each view in the layout and return the layout view.
     *
     * @param pos
     * @param inView
     * @param parent
     * @return view
     */

    public View getView(int pos, View inView, ViewGroup parent) {
        View v = inView;
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.ordered_row, null);
        }
        this.c.moveToPosition(pos);
        String idd = this.c.getString(this.c.getColumnIndex("_id"));
        final String itemid = this.c.getString(this.c.getColumnIndex("itemid"));
        final String title = this.c.getString(this.c.getColumnIndex("title"));
        final String price = this.c.getString(this.c.getColumnIndex("price"));
        String image = this.c.getString(this.c.getColumnIndex("image"));
        String seller = this.c.getString(this.c.getColumnIndex("seller"));
        final String quantity = this.c.getString(this.c.getColumnIndex("qty"));
        final String oderdate = this.c.getString(this.c.getColumnIndex("orddate"));
        String returnaccepted = this.c.getString(this.c.getColumnIndex("returnaccept"));
        final String delivered = this.c.getString(this.c.getColumnIndex("delivered"));

        ImageView iv = (ImageView) v.findViewById(R.id.orderimage);

        if (image != "null") {

            Picasso.with(this.context)
                    .load(image)
                    .into(iv);
        } else {
            iv.setImageResource(R.drawable.logos);
        }

        final Button returnbtn = (Button) v.findViewById(R.id.btnreturn);
        returnbtn.setTag(R.id.idd, idd);
        returnbtn.setTag(R.id.returns, returnaccepted);
        Button cancelbtn = (Button) v.findViewById(R.id.btncancel);
        cancelbtn.setTag(R.id.idd, idd);
        cancelbtn.setTag(R.id.date, oderdate);
        returnbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String orderid = returnbtn.getTag(R.id.idd).toString();
                if (returnbtn.getTag(R.id.returns).equals("No")) {
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);

                    dialogBuilder.setTitle("Returning Order");
                    dialogBuilder.setMessage("Returns for this Item is not Accepted");
                    dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            dialog.dismiss();
                        }
                    });
                    AlertDialog b = dialogBuilder.create();
                    b.show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    final View dialogView = inflater.inflate(R.layout.returnreason, null);
                    builder.setView(dialogView);
                    // Set the dialog title
                    builder
                            // Specify the list array, the items to be selected by default (null for none),
                            // and the listener through which to receive callbacks when items are selected
                            // Set the action buttons
                            .setTitle("Specify Reason")
                            .setPositiveButton("Return Order", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    EditText reason = (EditText) dialogView.findViewById(R.id.reasontv);
                                    if (reason.getText().toString().matches("")) {
                                        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);

                                        dialogBuilder.setTitle("Returning Order");
                                        dialogBuilder.setMessage("Please Specify Reason");
                                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int whichButton) {
                                                dialog.dismiss();
                                            }
                                        });
                                        AlertDialog b = dialogBuilder.create();
                                        b.show();
                                    } else {
                                        BuyerDB db = new BuyerDB(context);
                                        db.execute("return", orderid, reason.getText().toString(), quantity);
                                        dialog.dismiss();
                                    }
                                }
                            })

                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            });
                    AlertDialog c = builder.create();
                    c.show();
                }
            }
        });

        cancelbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String orderid = v.getTag(R.id.idd).toString();
                final String delivery = delivered;
                if (delivery.contains("No")) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    final View dialogView = inflater.inflate(R.layout.returnreason, null);
                    builder.setView(dialogView);
                    // Set the dialog title
                    builder
                            // Specify the list array, the items to be selected by default (null for none),
                            // and the listener through which to receive callbacks when items are selected
                            // Set the action buttons
                            .setTitle("Specify Reason")
                            .setPositiveButton("Cancel Order", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    EditText reason = (EditText) dialogView.findViewById(R.id.reasontv);
                                    if (reason.getText().toString().matches("")) {
                                        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);

                                        dialogBuilder.setTitle("Cancelling Order");
                                        dialogBuilder.setMessage("Please Specify Reason");
                                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                                            public void onClick(DialogInterface dialog, int whichButton) {
                                                dialog.dismiss();
                                            }
                                        });
                                        AlertDialog b = dialogBuilder.create();
                                        b.show();
                                    } else {
                                        BuyerDB db = new BuyerDB(context);
                                        db.execute("cancel", orderid, reason.getText().toString(), quantity);
                                        dialog.dismiss();
                                    }
                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.dismiss();
                                }
                            });
                    AlertDialog c = builder.create();
                    c.show();
                } else {
                    AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);

                    dialogBuilder.setTitle("Cancelling Order");
                    dialogBuilder.setMessage("Item is Already Delivered\nIts Too Late to Cancel Your Order Now");
                    dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            dialog.dismiss();
                        }
                    });
                    AlertDialog b = dialogBuilder.create();
                    b.show();
                }
            }
        });

        TextView ettitle = (TextView) v.findViewById(R.id.ordtitle);
        ettitle.setText(title);
        ettitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, ItemActivity.class);
                i.putExtra("selected", itemid);
                context.startActivity(i);
            }
        });

        TextView etquantity = (TextView) v.findViewById(R.id.ordqty);
        etquantity.setText(quantity);

        TextView etprice = (TextView) v.findViewById(R.id.ordprice);
        etprice.setText("£" + price);

        TextView etorddate = (TextView) v.findViewById(R.id.orddate);
        etorddate.setText(oderdate);

        TextView etdelivered = (TextView) v.findViewById(R.id.delivery);
        etdelivered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                android.support.v7.app.AlertDialog.Builder dialogBuilder = new android.support.v7.app.AlertDialog.Builder(context);

                dialogBuilder.setTitle("Delivery Details");
                dialogBuilder.setMessage("Item Delivered: " + delivered);
                dialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();

                    }
                });

                android.support.v7.app.AlertDialog b = dialogBuilder.create();
                b.show();
            }
        });

        return (v);
    }
}
