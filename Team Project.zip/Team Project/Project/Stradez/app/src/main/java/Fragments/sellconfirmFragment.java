package Fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.arslan.stradez.R;

/**
 * Created by Arslan on 25/12/2017.
 */

public class sellconfirmFragment extends Fragment {
    private static final String TAG = "Item Confirm";

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View mView = inflater.inflate(R.layout.fragment_sellconfirm, container, false);
        return mView;
    }
}
