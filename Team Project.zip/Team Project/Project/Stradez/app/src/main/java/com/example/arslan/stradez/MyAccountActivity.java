package com.example.arslan.stradez;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Database.AddressDB;
import Database.AuthanticateDB;

public class MyAccountActivity extends BaseActivity {

    String json_string;
    TextView fulname, usrname, email, phone, jdate, address;
    String f, s, u, e, ph, jd, full, houseno, street, city, country, postcode, method;
    Button addressbtn, terminate;
    final Context ctx = this;

    String username = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_account);
        addressbtn = (Button) findViewById(R.id.addbtn);
        terminate = (Button) findViewById(R.id.terminatbtn);

        SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
        username = sharedPref.getString("username", "");


        fulname = (TextView) findViewById(R.id.acfullna);
        usrname = (TextView) findViewById(R.id.acusrna);
        email = (TextView) findViewById(R.id.acemail);
        phone = (TextView) findViewById(R.id.acphnum);
        jdate = (TextView) findViewById(R.id.acdate);
        address = (TextView) findViewById(R.id.acaddress);

        new DB().execute("getuser");
        terminate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ctx);

                dialogBuilder.setTitle("Terminate Account");
                dialogBuilder.setMessage("Do You Really Want To Terminiate Your Account?");
                dialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        new DB().execute("terminate");
                    }
                });
                dialogBuilder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });
                AlertDialog b = dialogBuilder.create();
                b.show();
            }
        });

        onCreate();
    }

    public boolean validph(String phone) {

        String phoneRegEx = "\\d{11,16}";
        Pattern phpattern = Pattern.compile(phoneRegEx);
        Matcher phmatcher = phpattern.matcher(phone);
        if (phmatcher.find()) {
            return true;
        }
        return false;
    }

    public boolean validpass(String pass) {

        String passwordRegEx = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{6,20}$";
        Pattern passpattern = Pattern.compile(passwordRegEx);
        Matcher passmatcher = passpattern.matcher(pass);
        if (passmatcher.find()) {
            return true;
        }
        return false;
    }

    public void showResult(String result) {
        new DB().execute("getuser");
        Toast.makeText(this, result, Toast.LENGTH_LONG).show();
    }

    public void onEditclk(View v) {

        if (v.getId() == R.id.detailbtn) {

            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
            LayoutInflater inflater = this.getLayoutInflater();
            final View dialogView = inflater.inflate(R.layout.editform, null);
            dialogBuilder.setView(dialogView);

            final EditText etfname = (EditText) dialogView.findViewById(R.id.edfna);
            final EditText etsrname = (EditText) dialogView.findViewById(R.id.edsna);
            final EditText etphone = (EditText) dialogView.findViewById(R.id.edphno);
            final EditText etpass = (EditText) dialogView.findViewById(R.id.edpass);
            final EditText etpasscon = (EditText) dialogView.findViewById(R.id.edconpass);

            etfname.setText(f);
            etsrname.setText(s);
            etphone.setText(ph);

            Button modify = (Button) dialogView.findViewById(R.id.edbted);
            Button cancel = (Button) dialogView.findViewById(R.id.edbtcan);


            final AlertDialog b = dialogBuilder.create();
            b.show();

            modify.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (etfname.getText().toString().isEmpty() || etsrname.getText().toString().isEmpty() ||
                            etphone.getText().toString().isEmpty()
                            || etpass.getText().toString().isEmpty()) {
                        android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(ctx);

                        dialogBuilder.setTitle("Incorrect Details");
                        dialogBuilder.setMessage("Please Enter All Details");
                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });
                        android.app.AlertDialog b = dialogBuilder.create();
                        b.show();
                    } else if (!validph(etphone.getText().toString())) {
                        android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(ctx);

                        dialogBuilder.setTitle("Incorrect Phone Number");
                        dialogBuilder.setMessage("Please Enter Correct Phone Number \nFor Example: (0)7558544452 \n(+)44 7558544452");
                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });
                        android.app.AlertDialog b = dialogBuilder.create();
                        b.show();

                    } else if (!etpass.getText().toString().equals(etpasscon.getText().toString())) {
                        android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(ctx);

                        dialogBuilder.setTitle("Incorrect Password");
                        dialogBuilder.setMessage("Confirm Password is not same");
                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });
                        android.app.AlertDialog b = dialogBuilder.create();
                        b.show();
                    } else if (!validpass(etpass.getText().toString())) {
                        android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(ctx);

                        dialogBuilder.setTitle("Poor Password");
                        dialogBuilder.setMessage("Password Rquirment: \n" +
                                "a digit must occur at least once\n" +
                                "a lower case letter must occur at least once\n" +
                                "an upper case letter must occur at least once\n" +
                                "a special character must occur at least once you can replace with your special characters\n" +
                                "no whitespace allowed in the entire string\n" +
                                "at least eight characters");
                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });
                        android.app.AlertDialog b = dialogBuilder.create();
                        b.show();
                    } else {
                        AuthanticateDB db = new AuthanticateDB(ctx);
                        db.execute("modify", etfname.getText().toString(), etsrname.getText().toString(), username,
                                etphone.getText().toString(), etpass.getText().toString());
                        b.dismiss();
                    }
                }
            });

            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    b.dismiss();
                }
            });
        }

        final String method;


        if (v.getId() == R.id.addbtn) {
            if (addressbtn.getText().equals("Add")) {
                method = "add";
            } else {
                method = "edit";
            }

            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
            LayoutInflater inflater = this.getLayoutInflater();
            final View dialogView = inflater.inflate(R.layout.addressform, null);
            dialogBuilder.setView(dialogView);

            final EditText ethouseno = (EditText) dialogView.findViewById(R.id.addhouno);
            final EditText etstreet = (EditText) dialogView.findViewById(R.id.addstreet);
            final EditText etcity = (EditText) dialogView.findViewById(R.id.addcity);
            final EditText etcountry = (EditText) dialogView.findViewById(R.id.addcountry);
            final EditText etpostcode = (EditText) dialogView.findViewById(R.id.addpost);

            ethouseno.setText(houseno);
            etstreet.setText(street);
            etcity.setText(city);
            etcountry.setText(country);
            etpostcode.setText(postcode);

            Button save = (Button) dialogView.findViewById(R.id.addsavbtn);
            Button cancel = (Button) dialogView.findViewById(R.id.addcanbtn);

            final AlertDialog b = dialogBuilder.create();
            b.show();

            save.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (ethouseno.getText().toString().isEmpty() || etstreet.getText().toString().isEmpty() ||
                            etcity.getText().toString().isEmpty() || etcountry.getText().toString().isEmpty() ||
                            etpostcode.getText().toString().isEmpty()) {
                        android.app.AlertDialog.Builder dialogBuilder = new android.app.AlertDialog.Builder(ctx);

                        dialogBuilder.setTitle("Incorrect Details");
                        dialogBuilder.setMessage("Please Enter All Details");
                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });
                        android.app.AlertDialog b = dialogBuilder.create();
                        b.show();

                    } else {
                        AddressDB db = new AddressDB(ctx);
                        db.execute(method, ethouseno.getText().toString(), etstreet.getText().toString(), username,
                                etcity.getText().toString(), etcountry.getText().toString(),
                                etpostcode.getText().toString());
                        new DB().execute("getuser");
                        b.dismiss();
                    }
                }
            });

            cancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    b.dismiss();
                }
            });
        }
    }

    class DB extends AsyncTask<String, Void, String> {

        String json_url;

        @Override
        protected void onPreExecute() {
            json_url = "https://selene.hud.ac.uk/kingsman/getuser.php";
        }

        @Override
        protected String doInBackground(String... strings) {
            method = strings[0];
            if (method.equals("terminate")) {
                json_url = "https://selene.hud.ac.uk/kingsman/deleteuser.php";
            }
            try {
                URL url = new URL(json_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                while ((json_string = bufferedReader.readLine()) != null) {
                    stringBuilder.append(json_string + "\n");
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return stringBuilder.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                if (method.equals("terminate")) {
                    if (result.contains("error")) {
                        Toast.makeText(ctx, "Error Please Try Again", Toast.LENGTH_LONG).show();
                    } else {
                        SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
                        String username = sharedPref.getString("username", "");
                        SharedPreferences.Editor editor = sharedPref.edit();
                        editor.clear();
                        editor.apply();
                        Intent m = new Intent(getBaseContext(), HomeActivity.class);
                        m.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        Toast.makeText(ctx, result, Toast.LENGTH_LONG).show();
                        startActivity(m);
                    }

                } else {
                    try {
                        JSONObject res = new JSONObject(result);
                        JSONArray jsonArray = res.getJSONArray("server_response");
                        JSONObject jsonObject = jsonArray.getJSONObject(0);


                        full = jsonObject.getString("firstname") + " " + jsonObject.getString("surname");
                        f = jsonObject.getString("firstname");
                        s = jsonObject.getString("surname");
                        u = jsonObject.getString("username");
                        e = jsonObject.getString("email");
                        ph = jsonObject.getString("phone");
                        jd = jsonObject.getString("joindate");

                        JSONObject jsonObj = jsonArray.getJSONObject(0);
                        String addre = jsonObj.getString("houseno") + " " + jsonObj.getString("street") + "\n" + jsonObj.getString("city")
                                + "\n" + jsonObj.getString("country")
                                + "\n" + jsonObj.getString("postcode");

                        String no = jsonObj.getString("houseno");

                        fulname.setText(full);
                        usrname.setText(u);
                        email.setText(e);
                        phone.setText(ph);
                        jdate.setText(jd);

                        if (no != "null") {
                            addressbtn.setText("Edit");
                            address.setText(addre);
                            houseno = jsonObj.getString("houseno");
                            street = jsonObj.getString("street");
                            city = jsonObj.getString("city");
                            country = jsonObj.getString("country");
                            postcode = jsonObj.getString("postcode");
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
