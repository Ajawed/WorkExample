package Adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.example.arslan.stradez.R;
import com.example.arslan.stradez.SellHistoryActivity;
import com.example.arslan.stradez.ItemActivity;
import com.squareup.picasso.Picasso;

import Database.ItemDB;

/**
 * OrdersListAdapter class is used to adapt the cursor in the Listview.
 * <p>
 * Created by Arslan on 18/02/2018.
 */

public class OrdersListAdapter extends SimpleCursorAdapter {

    private Cursor c;
    private Context context;

    /**
     * Constructer for OrdersListAdapter
     *
     * @param context
     * @param layout
     * @param c
     * @param from
     * @param to
     * @param flags
     */

    public OrdersListAdapter(Context context, int layout, Cursor c, String[] from, int[] to, int flags) {
        super(context, layout, c, from, to, flags);
        this.c = c;
        this.context = context;
    }

    /**
     * this method set values of each view in the layout and return the layout view.
     *
     * @param pos
     * @param inView
     * @param parent
     * @return view
     */

    public View getView(int pos, View inView, ViewGroup parent) {
        View v = inView;
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.orders_row, null);
        }
        this.c.moveToPosition(pos);
        final String idd = this.c.getString(this.c.getColumnIndex("_id"));
        final String itemid = this.c.getString(this.c.getColumnIndex("itemid"));
        String title = this.c.getString(this.c.getColumnIndex("title"));
        String price = this.c.getString(this.c.getColumnIndex("price"));
        String date = this.c.getString(this.c.getColumnIndex("orddate"));
        String qty = this.c.getString(this.c.getColumnIndex("qty"));
        String image = this.c.getString(this.c.getColumnIndex("image"));
        final String buyer = this.c.getString(this.c.getColumnIndex("buyer"));
        final String phone = this.c.getString(this.c.getColumnIndex("phone"));
        final String Address = this.c.getString(this.c.getColumnIndex("houseno")) + "\n" + this.c.getString(this.c.getColumnIndex("street"))
                + "\n" + this.c.getString(this.c.getColumnIndex("city")) + "\n" + this.c.getString(this.c.getColumnIndex("country"))
                + "\n" + this.c.getString(this.c.getColumnIndex("postcode"));
        final String delivered = this.c.getString(this.c.getColumnIndex("delivered"));

        ImageView iv = (ImageView) v.findViewById(R.id.soldimage);

        if (image != "null") {

            Picasso.with(this.context)
                    .load(image)
                    .into(iv);
        } else {
            iv.setImageResource(R.drawable.logos);
        }

        Button dispbtn = (Button) v.findViewById(R.id.btndispatch);

        dispbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);

                dialogBuilder.setTitle("Item Delivered");
                dialogBuilder.setMessage("Have you Delivered the Item?");
                dialogBuilder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                        ItemDB db = new ItemDB(context);
                        db.execute("delivered", idd);

                    }
                });
                dialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });
                AlertDialog b = dialogBuilder.create();
                b.show();

            }
        });

        TextView ettitle = (TextView) v.findViewById(R.id.soldtitle);
        ettitle.setText(title);
        ettitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, ItemActivity.class);
                i.putExtra("selected", itemid);
                context.startActivity(i);
            }
        });

        TextView etprice = (TextView) v.findViewById(R.id.soldprice);
        etprice.setText("£" + price);

        TextView etselldate = (TextView) v.findViewById(R.id.selldate);
        etselldate.setText(date);

        TextView etqty = (TextView) v.findViewById(R.id.soldqty);
        etqty.setText(qty);

        TextView etdetail = (TextView) v.findViewById(R.id.deliverydetail);
        etdetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);

                dialogBuilder.setTitle("Buyer Details");
                dialogBuilder.setMessage("Buyer Name: " + buyer + "\n\nPhone: " + phone + "\n\nAddress: \n" + Address + "\n\nItem Delivered: " + delivered);
                dialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();

                    }
                });

                AlertDialog b = dialogBuilder.create();
                b.show();

            }
        });

        return (v);
    }
}
