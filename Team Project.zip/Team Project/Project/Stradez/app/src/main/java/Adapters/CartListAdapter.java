package Adapters;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.example.arslan.stradez.R;
import com.example.arslan.stradez.ItemActivity;
import com.squareup.picasso.Picasso;

/**
 * CartListAdapter class is used to adapt the cursor in the Listview.
 * <p>
 * Created by Arslan on 18/02/2018.
 */

public class CartListAdapter extends SimpleCursorAdapter {

    private Cursor c;
    private Context context;
    String idd;

    /**
     * Constructer for CartListAdapter
     *
     * @param context
     * @param layout
     * @param c
     * @param from
     * @param to
     * @param flags
     */

    public CartListAdapter(Context context, int layout, Cursor c, String[] from, int[] to, int flags) {
        super(context, layout, c, from, to, flags);
        this.c = c;
        this.context = context;
    }

    /**
     * this method set values of each view in the layout and return the layout view.
     *
     * @param pos
     * @param inView
     * @param parent
     * @return view
     */

    public View getView(int pos, View inView, ViewGroup parent) {
        View v = inView;
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.cart_row, null);
        }
        this.c.moveToPosition(pos);
        idd = this.c.getString(this.c.getColumnIndex("_id"));
        String title = this.c.getString(this.c.getColumnIndex("title"));
        String price = this.c.getString(this.c.getColumnIndex("price"));
        String method = this.c.getString(this.c.getColumnIndex("method"));
        String postprice = this.c.getString(this.c.getColumnIndex("postpr"));
        String image = this.c.getString(this.c.getColumnIndex("image"));
        String qty = this.c.getString(this.c.getColumnIndex("qty"));


        ImageView iv = (ImageView) v.findViewById(R.id.cartimage);

        if (image != "null") {

            Picasso.with(this.context)
                    .load(image)
                    .into(iv);
        } else {
            iv.setImageResource(R.drawable.logos);
        }


        Button btn = (Button) v.findViewById(R.id.btnrmcart);
        btn.setTag(idd);

        TextView ettitle = (TextView) v.findViewById(R.id.carttitle);
        ettitle.setText(title);
        ettitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, ItemActivity.class);
                i.putExtra("selected", idd);
                context.startActivity(i);
            }
        });

        TextView etprice = (TextView) v.findViewById(R.id.cartprice);
        etprice.setText("£" + price);

        TextView etpostmethod = (TextView) v.findViewById(R.id.cartpostmeth);
        etpostmethod.setText(method);

        TextView etqty = (TextView) v.findViewById(R.id.cartqty);
        etqty.setText(qty);

        TextView etpostprice = (TextView) v.findViewById(R.id.cartpostpr);
        etpostprice.setText("£" + postprice);

        return (v);
    }

}

