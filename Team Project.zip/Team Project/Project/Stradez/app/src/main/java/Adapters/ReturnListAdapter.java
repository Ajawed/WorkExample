package Adapters;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.example.arslan.stradez.R;
import com.squareup.picasso.Picasso;

/**
 * ReturnListAdapter class is used to adapt the cursor in the Listview.
 * <p>
 * Created by Arslan on 18/02/2018.
 */

public class ReturnListAdapter extends SimpleCursorAdapter {

    private Cursor c;
    private Context context;

    /**
     * Constructer for ReturnListAdapter
     *
     * @param context
     * @param layout
     * @param c
     * @param from
     * @param to
     * @param flags
     */

    public ReturnListAdapter(Context context, int layout, Cursor c, String[] from, int[] to, int flags) {
        super(context, layout, c, from, to, flags);
        this.c = c;
        this.context = context;
    }

    /**
     * this method set values of each view in the layout and return the layout view.
     *
     * @param pos
     * @param inView
     * @param parent
     * @return view
     */

    public View getView(int pos, View inView, ViewGroup parent) {
        View v = inView;
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.return_row, null);
        }
        this.c.moveToPosition(pos);
        String title = this.c.getString(this.c.getColumnIndex("title"));
        String price = this.c.getString(this.c.getColumnIndex("price"));
        String image = this.c.getString(this.c.getColumnIndex("image"));
        String seller = this.c.getString(this.c.getColumnIndex("seller"));
        String date = this.c.getString(this.c.getColumnIndex("date"));
        String reason = this.c.getString(this.c.getColumnIndex("reason"));

        ImageView iv = (ImageView) v.findViewById(R.id.rtnimage);

        if (image != "null") {

            Picasso.with(this.context)
                    .load(image)
                    .into(iv);
        } else {
            iv.setImageResource(R.drawable.logos);
        }


        TextView ettitle = (TextView) v.findViewById(R.id.rtntitle);
        ettitle.setText(title);

        TextView etprice = (TextView) v.findViewById(R.id.rtnprice);
        etprice.setText("£" + price);

        TextView etdate = (TextView) v.findViewById(R.id.rtndate);
        etdate.setText(date);

        TextView etreason = (TextView) v.findViewById(R.id.rtnreason);
        etreason.setText(reason);

        return (v);
    }
}
