package com.example.arslan.stradez;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class OrderConfirmActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setContentView(R.layout.activity_order_confirm);
        super.onCreate(savedInstanceState);

        TextView purchasetx = (TextView) findViewById(R.id.purchaselink);

        purchasetx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mintent = new Intent(OrderConfirmActivity.this, PurchaseHistoryActivity.class);
                startActivity(mintent);
            }
        });

        onCreate();
    }
}
