package Fragments;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ToggleButton;

import com.example.arslan.stradez.R;


/**
 * Created by Arslan on 25/12/2017.
 */

public class selldetailFragment extends Fragment {
    private static final String TAG = "Item Detail";

    ToggleButton toggleButton;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View mView = inflater.inflate(R.layout.fragment_selldetail, container, false);
        toggleButton = (ToggleButton) mView.findViewById(R.id.togglebutton);
        toggleButton.setText("No");
        toggleButton.setTextOff("No");
        toggleButton.setTextOn("Yes");
        return mView;
    }
}
