package Adapters;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * SectionsPageAdapter class is used to adapt fragments in viewpager
 * Created by Arslan Jawed on 27/03/2017.
 */
public class SectionsPageAdapter extends FragmentPagerAdapter {

    private final List<Fragment> mFragmentList = new ArrayList<>();
    private final List<String> mFragmentTitleList = new ArrayList<>();

    /**
     * This method add Fragments in the list and title of the fragment in the fragments list
     *
     * @param fragment
     * @param title
     */

    public void addFragment(Fragment fragment, String title) {
        mFragmentList.add(fragment);
        mFragmentTitleList.add(title);
    }

    /**
     * Constructer for SectionsPageAdapter
     *
     * @param fm
     */
    public SectionsPageAdapter(FragmentManager fm) {
        super(fm);
    }

    /**
     * this method returns fragment title at the given position
     *
     * @param position
     * @return
     */

    @Override
    public CharSequence getPageTitle(int position) {
        return mFragmentTitleList.get(position);
    }

    /**
     * this method returns fragment at the given position
     *
     * @param position
     * @return
     */

    @Override
    public Fragment getItem(int position) {
        return mFragmentList.get(position);
    }

    /**
     * this method returns number of fragments in the adapter
     *
     * @return
     */
    @Override
    public int getCount() {
        return mFragmentList.size();
    }
}
