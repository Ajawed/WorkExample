package Database;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.arslan.stradez.MyAccountActivity;
import com.example.arslan.stradez.PurchaseHistoryActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * BuyerDB class used to return and cancel item
 * Created by Arslan on 08/01/2018.
 */
public class BuyerDB extends AsyncTask<String, Void, String> {
    AlertDialog alertDialog;
    Context ctx;
    String method;
    String usernam;

    public BuyerDB(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPreExecute() {
    }

    @Override
    protected String doInBackground(String... params) {
        String urll = "https://selene.hud.ac.uk/kingsman/returnitem.php";
        method = params[0];
        if (method.equals("cancel")) {
            urll = "https://selene.hud.ac.uk/kingsman/cancelitem.php";
        }
        String orderid = params[1];
        String reason = params[2];
        String qty = params[3];
        try {
            URL url = new URL(urll);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream OS = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(OS, "UTF-8"));
            String data = URLEncoder.encode("order_id", "UTF-8") + "=" + URLEncoder.encode(orderid, "UTF-8") + "&" +
                    URLEncoder.encode("reason", "UTF-8") + "=" + URLEncoder.encode(reason, "UTF-8") + "&" +
                    URLEncoder.encode("qty", "UTF-8") + "=" + URLEncoder.encode(qty, "UTF-8");
            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();
            OS.close();
            InputStream IS = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS));
            String response = bufferedReader.readLine();
            bufferedReader.close();
            IS.close();
            httpURLConnection.connect();
            httpURLConnection.disconnect();
            return response;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    /**
     * After the ececution onPostExecute call restart method in PurchaseHistory activity
     * and parse result
     *
     * @param result
     */
    @Override
    protected void onPostExecute(String result) {

        ((PurchaseHistoryActivity) ctx).restart(result);
    }
}

