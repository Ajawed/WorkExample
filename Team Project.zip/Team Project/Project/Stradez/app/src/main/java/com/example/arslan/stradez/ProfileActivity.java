package com.example.arslan.stradez;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

public class ProfileActivity extends BaseActivity {

    TextView fulname, email, phone, jdate, address;
    String json_string;
    String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        username = getIntent().getStringExtra("seller");

        onCreate();

        fulname = (TextView) findViewById(R.id.prfname);
        email = (TextView) findViewById(R.id.prfemail);
        phone = (TextView) findViewById(R.id.prfphone);
        jdate = (TextView) findViewById(R.id.prfdate);
        address = (TextView) findViewById(R.id.prfaddress);

        new Backgroundw().execute();
    }

    public void onProfclk(View v) {
        if (v.getId() == R.id.selleritems) {
            Intent mintent = new Intent(ProfileActivity.this, SellersItemActivity.class);
            mintent.putExtra("seller", username);
            startActivity(mintent);
        }
    }

    class Backgroundw extends AsyncTask<Void, Void, String> {

        String json_url;

        @Override
        protected void onPreExecute() {
            json_url = "https://selene.hud.ac.uk/kingsman/getseller.php";
        }

        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL(json_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(username, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                while ((json_string = bufferedReader.readLine()) != null) {
                    stringBuilder.append(json_string + "\n");
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return stringBuilder.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject res = new JSONObject(result);
                    JSONArray jsonArray = res.getJSONArray("server_response");
                    JSONObject jsonObject = jsonArray.getJSONObject(0);

                    String f = jsonObject.getString("firstname") + " " + jsonObject.getString("surname");
                    String e = jsonObject.getString("email");
                    String ph = jsonObject.getString("phone");
                    String jd = jsonObject.getString("joindate");
                    String addre = jsonObject.getString("postcode");

                    fulname.setText(f);
                    email.setText(e);
                    phone.setText(ph);
                    jdate.setText(jd);

                    if (addre.isEmpty()) {
                    } else {
                        address.setText(addre);
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
