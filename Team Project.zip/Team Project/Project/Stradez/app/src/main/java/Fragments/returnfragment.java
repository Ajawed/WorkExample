package Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.MatrixCursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.arslan.stradez.PurchaseHistoryActivity;
import com.example.arslan.stradez.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import Adapters.ReturnListAdapter;
import Adapters.SearchListAdapter;

/**
 * Created by Arslan on 25/12/2017.
 */

public class returnfragment extends Fragment {
    private static final String TAG = "returnfragment";
    ListView rtnlist;
    MatrixCursor matrixCursor;
    TextView rtnres;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View mView = inflater.inflate(R.layout.returnfragment, container, false);
        rtnlist = (ListView) mView.findViewById(R.id.returnlist);

        SharedPreferences sharedPref = getActivity().getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
        String user = sharedPref.getString("username", "");

        rtnres = (TextView) mView.findViewById(R.id.rtnres);

        DB helper = new DB();
        helper.execute(user);

        return mView;
    }


    class DB extends AsyncTask<String, Void, String> {
        String resultstring;
        String srch_url;
        Context ctx = getActivity();

        //        public DB(Context ctx)
//        {
//            this.ctx =ctx;
//        }
        @Override
        protected void onPreExecute() {
            srch_url = "https://selene.hud.ac.uk/kingsman/returns.php";
        }

        @Override
        protected String doInBackground(String... strings) {

            String query = strings[0];

            try {
                URL url = new URL(srch_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                while ((resultstring = bufferedReader.readLine()) != null) {
                    stringBuilder.append(resultstring + "\n");
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return stringBuilder.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {

                String id, orderid, returndate, reason, quantity, username, orddate, seller, title, image, price;

                matrixCursor = new MatrixCursor(new String[]{"_id", "orderid", "date", "reason", "quantity", "username", "orddate",
                        "seller", "title", "image", "price"});

                JSONObject res = null;
                try {
                    res = new JSONObject(result);
                    JSONArray jsonArray = res.getJSONArray("server_response");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        id = jsonObject.getString("returnid");
                        orderid = jsonObject.getString("orderid");
                        returndate = jsonObject.getString("returndate");
                        reason = jsonObject.getString("reason");
                        quantity = jsonObject.getString("quantity");
                        username = jsonObject.getString("username");
                        orddate = jsonObject.getString("orderdate");
                        seller = jsonObject.getString("seller");
                        title = jsonObject.getString("title");
                        image = jsonObject.getString("image");
                        price = jsonObject.getString("price");

                        matrixCursor.addRow(new Object[]{id, orderid, returndate, reason, quantity,
                                username, orddate, seller, title, image, price});
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String[] fromfieldsNames = new String[]{"title", "image", "price", "date", "reason"};
                int[] toViewIds = new int[]{R.id.rtntitle, R.id.rtnimage, R.id.rtnprice, R.id.rtndate, R.id.rtnreason};

                BaseAdapter adapter = new ReturnListAdapter(
                        ctx, R.layout.return_row, matrixCursor, fromfieldsNames, toViewIds, 0);

                rtnres.setText("You Have " + String.valueOf(matrixCursor.getCount() + " Returned Orders "));

                rtnlist.setAdapter(adapter);
            }
        }
    }
}