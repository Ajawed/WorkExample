package com.example.arslan.stradez;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import Adapters.SearchListAdapter;

public class SearchResultsActivity extends BaseActivity {

    ListView srchlist;
    MatrixCursor matrixCursor;
    TextView resultinfo;
    String query;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_results);
        srchlist = (ListView) findViewById(R.id.srchlist);
        resultinfo = (TextView) findViewById(R.id.searchres);

        handleIntent(getIntent());
        onCreate();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {

        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String query = intent.getStringExtra(SearchManager.QUERY);
            resultinfo.setText(String.valueOf(0 + " Results For " + query));
            DB helper = new DB(this);
            helper.execute(query);

            AdapterView.OnItemClickListener onItemClickListener = new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Cursor item = (Cursor) srchlist.getItemAtPosition(position);
                    String selected = item.getString(0);

                    Intent i = new Intent(SearchResultsActivity.this, ItemActivity.class);
                    i.putExtra("selected", selected);
                    startActivity(i);

                }
            };
            srchlist.setOnItemClickListener(onItemClickListener);
        }
    }

    class DB extends AsyncTask<String, Void, String> {
        String resultstring;
        String srch_url;
        Context ctx;

        public DB(Context ctx) {
            this.ctx = ctx;
        }

        @Override
        protected void onPreExecute() {
            srch_url = "https://selene.hud.ac.uk/kingsman/search.php";
        }

        @Override
        protected String doInBackground(String... strings) {

            query = strings[0];

            try {
                URL url = new URL(srch_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                while ((resultstring = bufferedReader.readLine()) != null) {
                    stringBuilder.append(resultstring + "\n");
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return stringBuilder.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {

            if (result != null) {

                String id, user, title, image, des, cond, price, loc, method, postpr, returnaccept, postdate;

                matrixCursor = new MatrixCursor(new String[]{"_id", "user", "title",
                        "des", "image", "cond", "price", "loc", "method", "postpr", "returnaccept", "postdate"});

                JSONObject res = null;
                try {
                    res = new JSONObject(result);
                    JSONArray jsonArray = res.getJSONArray("server_response");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        id = jsonObject.getString("itemid");
                        user = jsonObject.getString("username");
                        title = jsonObject.getString("title");
                        des = jsonObject.getString("description");
                        image = jsonObject.getString("image");
                        cond = jsonObject.getString("condition");
                        price = jsonObject.getString("price");
                        loc = jsonObject.getString("itemlocation");
                        method = jsonObject.getString("postage");
                        postpr = jsonObject.getString("postprice");
                        returnaccept = jsonObject.getString("returnaccepted");
                        postdate = jsonObject.getString("postdate");

                        matrixCursor.addRow(new Object[]{id, user, title, des, image, cond, price, loc,
                                method, postpr, returnaccept, postdate});
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String[] fromfieldsNames = new String[]{"title", "image", "price", "method", "postpr"};
                int[] toViewIds = new int[]{R.id.srhtitle, R.id.itemimage, R.id.srhpric, R.id.srhpost, R.id.srhposprice};

                BaseAdapter adapter = new SearchListAdapter(
                        ctx, R.layout.item_row, matrixCursor, fromfieldsNames, toViewIds, 0);
                resultinfo.setText(String.valueOf(matrixCursor.getCount() + " Results For " + query));

                srchlist.setAdapter(adapter);
            }
        }
    }
}
