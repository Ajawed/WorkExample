package Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.MatrixCursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.arslan.stradez.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import Adapters.OnSellItemListAdapter;

/**
 * Created by Arslan on 25/12/2017.
 */

public class itemonsellfragment extends Fragment {
    private static final String TAG = "ItemOnSellfragment";
    ListView selllist;
    MatrixCursor matrixCursor;
    String user;
    TextView sellingres;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View mView = inflater.inflate(R.layout.onsellitemfragment, container, false);
        selllist = (ListView) mView.findViewById(R.id.sellinglist);

        SharedPreferences sharedPref = getActivity().getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
        user = sharedPref.getString("username", "");

        sellingres = (TextView) mView.findViewById(R.id.sellingres);

        DB helper = new DB();
        helper.execute(user);

        return mView;
    }

    class DB extends AsyncTask<String, Void, String> {
        String resultstring;
        String srch_url;
        Context ctx = getActivity();

        //        public DB(Context ctx)
//        {
//            this.ctx =ctx;
//        }
        @Override
        protected void onPreExecute() {
            srch_url = "https://selene.hud.ac.uk/kingsman/ItemSelling.php";
        }

        @Override
        protected String doInBackground(String... strings) {

            String query = strings[0];

            try {
                URL url = new URL(srch_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("query", "UTF-8") + "=" + URLEncoder.encode(query, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                while ((resultstring = bufferedReader.readLine()) != null) {
                    stringBuilder.append(resultstring + "\n");
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return stringBuilder.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {

            if (result != null) {

                String id, user, title, image, des, cond, price, loc, method, postpr, returnaccept, postdate, qty;

                matrixCursor = new MatrixCursor(new String[]{"_id", "user", "title",
                        "des", "image", "cond", "price", "loc", "method", "postpr", "returnaccept", "postdate", "qty"});

                JSONObject res = null;
                try {
                    res = new JSONObject(result);
                    JSONArray jsonArray = res.getJSONArray("server_response");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        id = jsonObject.getString("itemid");
                        user = jsonObject.getString("username");
                        title = jsonObject.getString("title");
                        des = jsonObject.getString("description");
                        image = jsonObject.getString("image");
                        cond = jsonObject.getString("condition");
                        price = jsonObject.getString("price");
                        loc = jsonObject.getString("itemlocation");
                        method = jsonObject.getString("postage");
                        postpr = jsonObject.getString("postprice");
                        returnaccept = jsonObject.getString("returnaccepted");
                        postdate = jsonObject.getString("postdate");
                        qty = jsonObject.getString("qty");

                        matrixCursor.addRow(new Object[]{id, user, title, des, image, cond, price, loc,
                                method, postpr, returnaccept, postdate, qty});
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                String[] fromfieldsNames = new String[]{"title", "image", "price", "method", "postpr", "postdate"};
                int[] toViewIds = new int[]{R.id.selltitle, R.id.sellimage, R.id.sellprice, R.id.sellpostmeth, R.id.sellprice, R.id.selldate};

                BaseAdapter adapter = new OnSellItemListAdapter(
                        ctx, R.layout.onsellitem_row, matrixCursor, fromfieldsNames, toViewIds, 0);

                sellingres.setText("You Have " + String.valueOf(matrixCursor.getCount() + " Items On Sell"));

                selllist.setAdapter(adapter);
            } else {
                sellingres.setText("You Have " + "0" + " Items On Sell");

            }
        }
    }
}
