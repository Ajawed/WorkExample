package com.example.arslan.stradez;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.MatrixCursor;
import android.graphics.drawable.LayerDrawable;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import Adapters.BadgeDrawable;
import Adapters.CartListAdapter;
import Database.PlaceOrderDB;

public class CartActivity extends BaseActivity {

    MatrixCursor matrixCursor;
    ListView cartli;
    LayerDrawable icon;
    double totalamount;
    TextView ettotalamount;
    BadgeDrawable badge;
    String cart;
    TextView cartres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        ettotalamount = (TextView) findViewById(R.id.ttlammount);
        cartres = (TextView) findViewById(R.id.cartres);

        cartli = (ListView) findViewById(R.id.cartlist);
        create();

        onCreate();
    }

    public void create() {

        SharedPreferences sharedpref2 = getSharedPreferences("cartArray", Context.MODE_PRIVATE);
        cart = sharedpref2.getString("cartarray", null);
        totalamount = 0;
        if (cart != null) {
            String id, qty, title, image, des, cond, price, loc, method, postpr, returnaccept, postdate;

            matrixCursor = new MatrixCursor(new String[]{"_id", "title", "image", "price", "method", "postpr", "qty"});

            JSONObject res = null;
            try {
                res = new JSONObject(cart);
                JSONArray jsonArray = res.getJSONArray("cart");

                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    id = jsonObject.getString("ItemID");
                    title = jsonObject.getString("Title");
                    price = jsonObject.getString("Price");
                    totalamount = totalamount + (Double.parseDouble(jsonObject.getString("Price"))
                            + Double.parseDouble(jsonObject.getString("postprice")))
                            * Integer.parseInt(jsonObject.getString("AddedQty"));
                    qty = jsonObject.getString("AddedQty");
                    postpr = jsonObject.getString("postprice");
                    method = jsonObject.getString("method");
                    image = jsonObject.getString("image");

                    matrixCursor.addRow(new Object[]{id, title, image, price, method, postpr, qty});
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            String[] fromfieldsNames = new String[]{"title", "image", "price", "method", "postpr", "qty"};
            int[] toViewIds = new int[]{R.id.carttitle, R.id.cartimage, R.id.cartprice,
                    R.id.cartpostmeth, R.id.cartpostpr, R.id.cartqty};

            BaseAdapter madapter = new CartListAdapter(
                    this, R.layout.cart_row, matrixCursor, fromfieldsNames, toViewIds, 0);
            ettotalamount.setText(String.valueOf(totalamount));
            cartres.setText(String.valueOf(matrixCursor.getCount()) + " Items In Your Cart");
            cartli.setAdapter(madapter);
        } else {
            ettotalamount.setText(String.valueOf(totalamount));
            cartres.setText("0 Items In Your Cart");
        }
    }

    public void onCartclk(View v) throws JSONException {
        if (v.getId() == R.id.btnrmcart) {
            String itemid = v.getTag().toString();
            int qty = 0;
            SharedPreferences sharedpref2 = getSharedPreferences("cartArray", Context.MODE_PRIVATE);
            String cart = sharedpref2.getString("cartarray", "");
            JSONObject json = new JSONObject(cart);
            JSONArray array = json.getJSONArray("cart");

            for (int i = 0; i < array.length(); i++) {
                JSONObject jsonObj = array.getJSONObject(i);
                if (itemid.equals(jsonObj.getString("ItemID"))) {
                    qty = Integer.parseInt(jsonObj.getString("AddedQty"));
                    array.remove(i);
                    break;
                }
            }
            json.putOpt("cart", array);
            String cartArray = json.toString();
            SharedPreferences.Editor editor2 = sharedpref2.edit();
            editor2.putString("cartarray", cartArray);
            editor2.apply();

            SharedPreferences sharedPref = getSharedPreferences("cartcount", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPref.edit();
            int count = sharedPref.getInt("count", 0);
            count = count - qty;
            editor.putInt("count", count);
            editor.apply();

            icon = (LayerDrawable) itemCart.getIcon();
            badge.setBadgeCount(this, icon, String.valueOf(count));
            create();
        }
    }

    public void onOrder(View v) throws JSONException {

        if (cart != null) {

            SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
            String username = sharedPref.getString("username", "");

            if (username.equals("")) {
                AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                alertDialog.setTitle("Order Information");
                alertDialog.setMessage(" You Have to Login before Order");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            } else {

                SharedPreferences sharedpref2 = getSharedPreferences("cartArray", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor2 = sharedpref2.edit();
                editor2.clear();
                editor2.apply();

                SharedPreferences sharedPref1 = getSharedPreferences("cartcount", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref1.edit();
                int count = sharedPref1.getInt("count", 0);
                editor.putInt("count", 0);
                editor.apply();

                icon = (LayerDrawable) itemCart.getIcon();
                badge.setBadgeCount(this, icon, String.valueOf(0));

                JSONObject res = null;
                try {
                    res = new JSONObject(cart);
                    JSONArray jsonArray = res.getJSONArray("cart");

                    for (int i = 0; i < jsonArray.length(); i++) {

                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        String itemid = jsonObject.getString("ItemID");
                        String qty = jsonObject.getString("AddedQty");
                        String title = jsonObject.getString("Title");

                        PlaceOrderDB db = new PlaceOrderDB(this);
                        db.execute(username, itemid, qty, title);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                try {
                    Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                Intent myIntent = new Intent(CartActivity.this, OrderConfirmActivity.class);
                startActivity(myIntent);
            }
        } else {
            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setTitle("Empty Cart");
            alertDialog.setMessage(" Your Cart is Empty ");
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            alertDialog.show();
        }
    }


}
