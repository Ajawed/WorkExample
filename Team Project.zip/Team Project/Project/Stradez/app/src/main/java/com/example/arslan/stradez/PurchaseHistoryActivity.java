package com.example.arslan.stradez;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.widget.Toast;

import Adapters.SectionsPageAdapter;
import Fragments.cancelfragment;
import Fragments.orderedfragment;
import Fragments.returnfragment;

/**
 * Created by Arslan on 28/12/2017.
 */

public class PurchaseHistoryActivity extends BaseActivity {

    private static final String TAG = "PurchaseHistory";

    private SectionsPageAdapter mSecPageAdap;

    private ViewPager mViewPager;
    public String username;
    final Context ctx = this;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_purchase_history);

        SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
        username = sharedPref.getString("username", "");

        mSecPageAdap = new SectionsPageAdapter(getSupportFragmentManager());

        mViewPager = (ViewPager) findViewById(R.id.container);
        setupViewPager(mViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
        onCreate();
    }

    public void restart(String result) {
        setupViewPager(mViewPager);
        Toast.makeText(ctx, result, Toast.LENGTH_LONG).show();
    }

    private void setupViewPager(ViewPager viewPager) {
        SectionsPageAdapter adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new orderedfragment(), "Orders");
        adapter.addFragment(new returnfragment(), "Returned Items");
        adapter.addFragment(new cancelfragment(), "Canceled Items");
        viewPager.setAdapter(adapter);
    }

}

