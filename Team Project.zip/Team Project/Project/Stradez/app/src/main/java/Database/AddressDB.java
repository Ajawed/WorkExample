package Database;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.arslan.stradez.MyAccountActivity;
import com.example.arslan.stradez.PurchaseHistoryActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * AddressDB class used to add and edit address on the database
 * Created by Arslan on 7/14/2015.
 */
public class AddressDB extends AsyncTask<String, Void, String> {
    AlertDialog alertDialog;
    Context ctx;
    String method;
    String usernam;

    public AddressDB(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected String doInBackground(String... params) {
        String urll = "https://selene.hud.ac.uk/kingsman/addaddress.php";
        method = params[0];
        if (method.equals("edit")) {
            urll = "https://selene.hud.ac.uk/kingsman/editaddress.php";
        }
        String houseno = params[1];
        String street = params[2];
        String user_name = params[3];
        String city = params[4];
        String country = params[5];
        String postcode = params[6];
        try {
            URL url = new URL(urll);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream OS = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(OS, "UTF-8"));
            String data = URLEncoder.encode("house_no", "UTF-8") + "=" + URLEncoder.encode(houseno, "UTF-8") + "&" +
                    URLEncoder.encode("street", "UTF-8") + "=" + URLEncoder.encode(street, "UTF-8") + "&" +
                    URLEncoder.encode("user_name", "UTF-8") + "=" + URLEncoder.encode(user_name, "UTF-8") + "&" +
                    URLEncoder.encode("city", "UTF-8") + "=" + URLEncoder.encode(city, "UTF-8") + "&" +
                    URLEncoder.encode("country", "UTF-8") + "=" + URLEncoder.encode(country, "UTF-8") + "&" +
                    URLEncoder.encode("postcode", "UTF-8") + "=" + URLEncoder.encode(postcode, "UTF-8");
            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();
            OS.close();
            InputStream IS = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(IS));
            String response = bufferedReader.readLine();
            bufferedReader.close();
            IS.close();
            httpURLConnection.connect();
            httpURLConnection.disconnect();
            return response;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    /**
     * After the ececution onPostExecute call showResult method in MyAccount activity
     * and parse result
     *
     * @param result
     */

    @Override
    protected void onPostExecute(String result) {

        ((MyAccountActivity) ctx).showResult(result);

    }

}

