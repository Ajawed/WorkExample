package Adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.arslan.stradez.R;
import com.example.arslan.stradez.ItemActivity;
import com.squareup.picasso.Picasso;

import Database.ItemDB;
import Database.SellerDatabase;

/**
 * OnSellItemListAdapter class is used to adapt the cursor in the Listview.
 * <p>
 * Created by Arslan on 18/02/2018.
 */

public class OnSellItemListAdapter extends SimpleCursorAdapter {

    private Cursor c;
    private Context context;

    /**
     * Constructer for OnSellItemListAdapter
     *
     * @param context
     * @param layout
     * @param c
     * @param from
     * @param to
     * @param flags
     */

    public OnSellItemListAdapter(Context context, int layout, Cursor c, String[] from, int[] to, int flags) {
        super(context, layout, c, from, to, flags);
        this.c = c;
        this.context = context;
    }

    /**
     * this method set values of each view in the layout and return the layout view.
     *
     * @param pos
     * @param inView
     * @param parent
     * @return view
     */

    public View getView(int pos, View inView, ViewGroup parent) {
        View v = inView;
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.onsellitem_row, null);
        }
        this.c.moveToPosition(pos);
        final String idd = this.c.getString(this.c.getColumnIndex("_id"));
        final String title = this.c.getString(this.c.getColumnIndex("title"));
        final String des = this.c.getString(this.c.getColumnIndex("des"));
        final String cond = this.c.getString(this.c.getColumnIndex("cond"));
        final String loc = this.c.getString(this.c.getColumnIndex("loc"));
        final String price = this.c.getString(this.c.getColumnIndex("price"));
        final String method = this.c.getString(this.c.getColumnIndex("method"));
        final String postprice = this.c.getString(this.c.getColumnIndex("postpr"));
        final String rtn = this.c.getString(this.c.getColumnIndex("returnaccept"));
        final String qty = this.c.getString(this.c.getColumnIndex("qty"));
        String date = this.c.getString(this.c.getColumnIndex("postdate"));
        String image = this.c.getString(this.c.getColumnIndex("image"));

        ImageView iv = (ImageView) v.findViewById(R.id.sellitemimage);

        if (image != "null") {

            Picasso.with(this.context)
                    .load(image)
                    .into(iv);
        } else {
            iv.setImageResource(R.drawable.logos);
        }

        Button editbtn = (Button) v.findViewById(R.id.btnedsell);
        Button removebtn = (Button) v.findViewById(R.id.btnrmsell);

        editbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);
                LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                final View dialogView = inflater.inflate(R.layout.edititem, null);
                dialogBuilder.setView(dialogView);

                final EditText ettitle = (EditText) dialogView.findViewById(R.id.edittitle);
                final EditText etcondition = (EditText) dialogView.findViewById(R.id.editcond);
                final EditText etprice = (EditText) dialogView.findViewById(R.id.editprice);
                final EditText etlocation = (EditText) dialogView.findViewById(R.id.editloc);
                final EditText etmethod = (EditText) dialogView.findViewById(R.id.editmethod);
                final EditText etpostprice = (EditText) dialogView.findViewById(R.id.editpostprice);
                final ToggleButton btnrtnacp = (ToggleButton) dialogView.findViewById(R.id.togglebutton);
                final EditText etquantity = (EditText) dialogView.findViewById(R.id.editqty);
                final EditText etdescription = (EditText) dialogView.findViewById(R.id.editdes);

                btnrtnacp.setTextOff("No");
                btnrtnacp.setTextOn("Yes");

                ettitle.setText(title);
                etcondition.setText(cond);
                etprice.setText(price);
                etpostprice.setText(postprice);
                etlocation.setText(loc);
                etmethod.setText(method);
                etquantity.setText(qty);
                etdescription.setText(des);
                btnrtnacp.setText(rtn);

                Button edit = (Button) dialogView.findViewById(R.id.edbted);
                Button cancel = (Button) dialogView.findViewById(R.id.edbtcan);
                final AlertDialog b = dialogBuilder.create();

                edit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        SellerDatabase db = new SellerDatabase(context);
                        db.execute(idd, ettitle.getText().toString(), etprice.getText().toString(),
                                etcondition.getText().toString(), etlocation.getText().toString(),
                                etmethod.getText().toString(), etpostprice.getText().toString(),
                                btnrtnacp.getText().toString(), etquantity.getText().toString(),
                                etdescription.getText().toString());
                        b.dismiss();
                    }
                });
                b.show();
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        b.dismiss();
                    }
                });

            }
        });

        removebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(context);

                dialogBuilder.setTitle("Removing Item");
                dialogBuilder.setMessage("Do you Really Want to Remove Item From Sell?");
                dialogBuilder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {

                        ItemDB db = new ItemDB(context);
                        db.execute("delete", idd);
                    }
                });
                dialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });
                AlertDialog b = dialogBuilder.create();
                b.show();
            }
        });


        TextView ettitle = (TextView) v.findViewById(R.id.selltitle);
        ettitle.setText(title);
        ettitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, ItemActivity.class);
                i.putExtra("selected", idd);
                context.startActivity(i);
            }
        });

        TextView etprice = (TextView) v.findViewById(R.id.sellprice);
        etprice.setText("£" + price);

        TextView etpostmethod = (TextView) v.findViewById(R.id.sellpostmeth);
        etpostmethod.setText(method);

        TextView etpostprice = (TextView) v.findViewById(R.id.sellpostpric);
        etpostprice.setText("£" + postprice);

        TextView etselldate = (TextView) v.findViewById(R.id.selldate);
        etselldate.setText(date);

        return (v);
    }
}
