package com.example.arslan.stradez;

import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.LayerDrawable;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;


import Adapters.BadgeDrawable;

/**
 * BaseActivity has all the common methods and varaible every activty extends
 * Created by Arslan on 22/02/2018.
 */
public class BaseActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    BadgeDrawable badge;
    public MenuItem itemCart;
    public MenuItem about;
    public MenuItem policy;
    public MenuItem faqs;
    public boolean loggedin = true;

    /**
     * This method is set navigation drawer
     */

    public void onCreate() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.navdrawer);
        mToggle = new ActionBarDrawerToggle(this, mDrawerLayout, R.string.open, R.string.close);

        NavigationView navigation = (NavigationView) findViewById(R.id.navigationview);

        SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
        String username = sharedPref.getString("username", "");

        if (username.equals("")) {
            navigation.getMenu().getItem(5).setVisible(false);
            loggedin = false;
        }
        try {
            navigation.setNavigationItemSelectedListener(this);
        } catch (RuntimeException e) {
        }

        mDrawerLayout.addDrawerListener(mToggle);
        mToggle.syncState();

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    /**
     * This method set Toggle button on navigation drawer
     *
     * @param item
     * @return
     */

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (mToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * This method set all the menu items and their link
     *
     * @param menu
     * @return
     */

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.search_menu, menu);
        MenuItem searchitem = menu.findItem(R.id.search_item);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchitem);

        itemCart = menu.findItem(R.id.action_cart);
        LayerDrawable icon = (LayerDrawable) itemCart.getIcon();

        itemCart.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                                                @Override
                                                public boolean onMenuItemClick(MenuItem menuItem) {

                                                    Intent i = new Intent(getBaseContext(), CartActivity.class);
                                                    startActivity(i);
                                                    return true;
                                                }
                                            }

        );

        about = menu.findItem(R.id.action_about);
        policy = menu.findItem(R.id.action_PrivacyPolicy);
        faqs = menu.findItem(R.id.action_faq);

        about.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                                             @Override
                                             public boolean onMenuItemClick(MenuItem menuItem) {

                                                 Intent i = new Intent(getBaseContext(), AboutActivity.class);
                                                 startActivity(i);
                                                 return true;
                                             }
                                         }

        );
        policy.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                                              @Override
                                              public boolean onMenuItemClick(MenuItem menuItem) {

                                                  Intent i = new Intent(getBaseContext(), PrivacyPolicyActivity.class);
                                                  startActivity(i);
                                                  return true;
                                              }
                                          }

        );
        faqs.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
                                            @Override
                                            public boolean onMenuItemClick(MenuItem menuItem) {

                                                Intent i = new Intent(getBaseContext(), FaqActivity.class);
                                                startActivity(i);
                                                return true;
                                            }
                                        }

        );

        SharedPreferences sharedPref = getSharedPreferences("cartcount", Context.MODE_PRIVATE);
        int count = sharedPref.getInt("count", 0);

        badge.setBadgeCount(this, icon, String.valueOf(count));

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        ComponentName componentName = new ComponentName(this, SearchResultsActivity.class);
        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName));

        return true;
    }

    /**
     * this method set links on views on the footer
     *
     * @param v
     */

    public void onfooterclk(View v) {
        if (v.getId() == R.id.about) {
            Intent mintent = new Intent(getBaseContext(), AboutActivity.class);
            startActivity(mintent);
        }
        if (v.getId() == R.id.policy) {
            Intent mintent = new Intent(getBaseContext(), PrivacyPolicyActivity.class);
            startActivity(mintent);

        }
        if (v.getId() == R.id.faq) {
            Intent mintent = new Intent(getBaseContext(), FaqActivity.class);
            startActivity(mintent);
        }
    }

    /**
     * This method set links on the items on the navigation drawer
     *
     * @param item
     * @return
     */

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        mDrawerLayout.closeDrawers();
        switch (id) {
            case R.id.action_home:
                Intent i = new Intent(getBaseContext(), HomeActivity.class);
                startActivity(i);
                break;
            case R.id.action_myaccount:
                if (loggedin == false) {
                    Intent myIntent = new Intent(getBaseContext(), Login_RegisterActivity.class);
                    myIntent.putExtra("activity", "com.example.arslan.stradez.MyAccountActivity");
                    startActivity(myIntent);
                } else {
                    Intent j = new Intent(getBaseContext(), MyAccountActivity.class);
                    startActivity(j);
                }
                break;
            case R.id.action_purchasehistory:
                if (loggedin == false) {
                    Intent myIntent = new Intent(getBaseContext(), Login_RegisterActivity.class);
                    myIntent.putExtra("activity", "com.example.arslan.stradez.PurchaseHistoryActivity");
                    startActivity(myIntent);
                } else {
                    Intent k = new Intent(getBaseContext(), PurchaseHistoryActivity.class);
                    startActivity(k);
                }
                break;
            case R.id.action_sell:
                if (loggedin == false) {
                    Intent myIntent = new Intent(getBaseContext(), Login_RegisterActivity.class);
                    myIntent.putExtra("activity", "com.example.arslan.stradez.sellActivity");
                    startActivity(myIntent);
                } else {
                    Intent l = new Intent(getBaseContext(), sellActivity.class);
                    startActivity(l);
                }
                break;
            case R.id.action_sellinghistory:
                if (loggedin == false) {
                    Intent myIntent = new Intent(getBaseContext(), Login_RegisterActivity.class);
                    myIntent.putExtra("activity", "com.example.arslan.stradez.SellHistoryActivity");
                    startActivity(myIntent);
                } else {
                    Intent n = new Intent(getBaseContext(), SellHistoryActivity.class);
                    startActivity(n);
                }
                break;
            case R.id.action_logout:
                SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
                String username = sharedPref.getString("username", "");
                SharedPreferences.Editor editor = sharedPref.edit();
                editor.clear();
                editor.apply();
                Intent m = new Intent(getBaseContext(), HomeActivity.class);
                m.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(m);
                break;
            case R.id.action_exit:
                Intent intent = new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
        }
        return false;
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

}
