package com.example.arslan.stradez;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.design.widget.TabLayout;

import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.View;

import android.widget.CheckBox;
import android.widget.EditText;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import Database.AuthanticateDB;
import Adapters.SectionsPageAdapter;
import Fragments.Registerfragment;
import Fragments.loginfragment;

public class Login_RegisterActivity extends BaseActivity {
    private static final String TAG = "Login_Register";

    public ViewPager mViewPager;
    EditText etusername, etpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login__register);

        mViewPager = (ViewPager) findViewById(R.id.container);
        setupViewPager(mViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        onCreate();
    }

    private void setupViewPager(ViewPager viewPager) {
        SectionsPageAdapter adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new loginfragment(), "Log in");
        adapter.addFragment(new Registerfragment(), "Register");
        viewPager.setAdapter(adapter);
    }

    public void onsignin(View v) {
        etusername = (EditText) findViewById(R.id.eusrname);
        etpassword = (EditText) findViewById(R.id.eusrpass);

        String login_name = etusername.getText().toString();
        String login_pass = etpassword.getText().toString();
        login(login_name, login_pass);
    }

    public void ontermsclk(View v) {
        if (v.getId() == R.id.terms) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
            dialogBuilder.setTitle("Terms And Condition");
            dialogBuilder.setMessage(R.string.TermsandCondition);
            dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                }
            });
            AlertDialog b = dialogBuilder.create();
            b.show();
        }
    }

    public void login(String login_name, String login_pass) {

        String method = "login";
        AuthanticateDB authanticateDB = new AuthanticateDB(this);
        authanticateDB.execute(method, login_name, login_pass, getIntent().getStringExtra("activity"));
    }

    public void onregis(View v) {
        EditText etfname = (EditText) findViewById(R.id.rgfname);
        EditText etsrname = (EditText) findViewById(R.id.rgsname);
        EditText etuname = (EditText) findViewById(R.id.rguname);
        EditText etemail = (EditText) findViewById(R.id.rgemail);
        EditText etphnum = (EditText) findViewById(R.id.rgpnum);
        EditText etpass = (EditText) findViewById(R.id.rgpass);
        EditText etconpass = (EditText) findViewById(R.id.rgcpass);

        String first_name = etfname.getText().toString();
        String surname = etsrname.getText().toString();
        String username = etuname.getText().toString();
        String email = etemail.getText().toString();
        String phone_num = etphnum.getText().toString();
        String password = etpass.getText().toString();
        String conpass = etconpass.getText().toString();

        register(first_name, surname, username, email, phone_num, password, conpass);
    }

    public void register(String first_name, String surname, String username, String email, String phone_num, String password, String conpass) {
        CheckBox terms = (CheckBox) findViewById(R.id.checkBox);

        String emailRegEx = "[u][0-9]{7}+@unimail.hud.ac.uk";
        String phoneRegEx = "\\d{11,16}";
        String passwordRegEx = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,20}$";
        // Compare the regex with the email address
        Pattern pattern = Pattern.compile(emailRegEx);
        Matcher matcher = pattern.matcher(email);

        Pattern phpattern = Pattern.compile(phoneRegEx);
        Matcher phmatcher = phpattern.matcher(phone_num);

        Pattern passpattern = Pattern.compile(passwordRegEx);
        Matcher passmatcher = passpattern.matcher(password);

        if (first_name.isEmpty() || surname.isEmpty() || username.isEmpty()
                || email.isEmpty() || phone_num.isEmpty()
                || password.isEmpty() || conpass.isEmpty()) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

            dialogBuilder.setTitle("Incorrect Details");
            dialogBuilder.setMessage("Please Enter All Details");
            dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                }
            });
            AlertDialog b = dialogBuilder.create();
            b.show();
        } else if (!terms.isChecked()) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

            dialogBuilder.setTitle("Terms And Condition");
            dialogBuilder.setMessage("Please Accept Terms and Conditions to Register");
            dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                }
            });
            AlertDialog b = dialogBuilder.create();
            b.show();

        } else if (!matcher.find()) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

            dialogBuilder.setTitle("Incorrect Email");
            dialogBuilder.setMessage("Only University Of Huddersfield Email is allowed \nUse Lower Case 'u'");
            dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                }
            });
            AlertDialog b = dialogBuilder.create();
            b.show();

        } else if (!phmatcher.find()) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

            dialogBuilder.setTitle("Incorrect Phone Number");
            dialogBuilder.setMessage("Please Enter Correct Phone Number \nFor Example: (0)7558544452");
            dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                }
            });
            AlertDialog b = dialogBuilder.create();
            b.show();

        } else if (!password.equals(conpass)) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

            dialogBuilder.setTitle("Incorrect Password");
            dialogBuilder.setMessage("Confirm Password is not same");
            dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                }
            });
            AlertDialog b = dialogBuilder.create();
            b.show();
        } else if (!passmatcher.find()) {
            AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);

            dialogBuilder.setTitle("Poor Password");
            dialogBuilder.setMessage("Password Rquirment: \n" +
                    "a digit must occur at least once\n" +
                    "a lower case letter must occur at least once\n" +
                    "an upper case letter must occur at least once\n" +
                    "a special character must occur at least once you can replace with your special characters\n" +
                    "no whitespace allowed in the entire string\n" +
                    "at least eight characters");
            dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int whichButton) {
                    dialog.dismiss();
                }
            });
            AlertDialog b = dialogBuilder.create();
            b.show();
        } else {
            String method = "register";
            AuthanticateDB authanticateDB = new AuthanticateDB(this);
            authanticateDB.execute(method, first_name, surname, username, email, phone_num, password);
        }
    }
}
