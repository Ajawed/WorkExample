package Adapters;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.example.arslan.stradez.R;
import com.squareup.picasso.Picasso;

import static java.lang.System.load;

/**
 * SearchListAdapter class is used to adapt the cursor in the Listview.
 * <p>
 * Created by Arslan on 18/02/2018.
 */

public class SearchListAdapter extends SimpleCursorAdapter {

    private Cursor c;
    private Context context;

    /**
     * Constructer for SearchListAdapter
     *
     * @param context
     * @param layout
     * @param c
     * @param from
     * @param to
     * @param flags
     */

    public SearchListAdapter(Context context, int layout, Cursor c, String[] from, int[] to, int flags) {
        super(context, layout, c, from, to, flags);
        this.c = c;
        this.context = context;
    }

    /**
     * this method set values of each view in the layout and return the layout view.
     *
     * @param pos
     * @param inView
     * @param parent
     * @return view
     */

    public View getView(int pos, View inView, ViewGroup parent) {
        View v = inView;
        if (v == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.item_row, null);
        }
        this.c.moveToPosition(pos);
        String title = this.c.getString(this.c.getColumnIndex("title"));
        String price = this.c.getString(this.c.getColumnIndex("price"));
        String method = this.c.getString(this.c.getColumnIndex("method"));
        String postprice = this.c.getString(this.c.getColumnIndex("postpr"));
        String image = this.c.getString(this.c.getColumnIndex("image"));

        ImageView iv = (ImageView) v.findViewById(R.id.itemimage);

        if (image != "null") {

            Picasso.with(this.context)
                    .load(image)
                    .into(iv);
        } else {
            iv.setImageResource(R.drawable.logos);
        }


        TextView ettitle = (TextView) v.findViewById(R.id.srhtitle);
        ettitle.setText(title);

        TextView etprice = (TextView) v.findViewById(R.id.srhpric);
        etprice.setText("£" + price);

        TextView etpostmethod = (TextView) v.findViewById(R.id.srhpost);
        etpostmethod.setText(method);

        TextView etpostprice = (TextView) v.findViewById(R.id.srhposprice);
        etpostprice.setText("£" + postprice);

        return (v);
    }
}
