package com.example.arslan.stradez;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

import Adapters.MySingleton;
import Adapters.SectionsPageAdapter;
import Fragments.sellcatFragment;
import Fragments.sellconfirmFragment;
import Fragments.selldetailFragment;
import Fragments.sellpicFragment;

public class sellActivity extends BaseActivity {

    private static final String TAG = "Sell_Activity";

    private ViewPager mViewPager;

    private int pos;

    public Bitmap bittmap;
    public String itemtitle;
    public String itemprice;
    public String condition;
    public String itemLocation;
    public String postagemethod;
    public String postageprice;
    public String returnAccept;
    public String quantity;
    public String description;
    public String itemimage;
    String user;

    Context ctx = this;

    boolean confirm = false;

    Button prevbton;
    Button nextbton;

    SectionsPageAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);
        SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
        user = sharedPref.getString("username", "");
        bittmap = BitmapFactory.decodeResource(getResources(), R.drawable.defaultimage);

        if (user == "") {
            Intent myIntent = new Intent(sellActivity.this, Login_RegisterActivity.class);
            startActivity(myIntent);
        }

        onCreate();


        mViewPager = (ViewPager) findViewById(R.id.sellwizard);
        setupViewPager(mViewPager);

        prevbton = (Button) findViewById(R.id.prevbtn);
        prevbton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nextbton.setText("Next");

                if (mViewPager.getCurrentItem() == 0) {
                } else {
                    pos--;
                    mViewPager.setCurrentItem(pos);
                    confirm = false;
                }

            }
        });

        nextbton = (Button) findViewById(R.id.nextbtn);
        nextbton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (confirm == true) {
                    uploadImage();
                } else {
                    EditText etitemtitle = (EditText) findViewById(R.id.ettitle);
                    EditText etprice = (EditText) findViewById(R.id.etprc);
                    EditText etcondition = (EditText) findViewById(R.id.etcond);
                    EditText etitemlocation = (EditText) findViewById(R.id.etitemloc);
                    EditText etpostmeth = (EditText) findViewById(R.id.etpostmeth);
                    EditText etpostprc = (EditText) findViewById(R.id.etpostprc);
                    Button rtnaccept = (Button) findViewById(R.id.togglebutton);
                    EditText etqty = (EditText) findViewById(R.id.etqty);
                    EditText etdescrip = (EditText) findViewById(R.id.etdescrip);

                    if (mViewPager.getCurrentItem() == adapter.getCount() - 2 && (etitemtitle.getText().toString().isEmpty()
                            || etprice.getText().toString().isEmpty() ||
                            etcondition.getText().toString().isEmpty() || etitemlocation.getText().toString().isEmpty() ||
                            etpostmeth.getText().toString().isEmpty() || etpostprc.getText().toString().isEmpty() || etqty.getText().toString().isEmpty()
                            || etdescrip.getText().toString().isEmpty())) {

                        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(ctx);

                        dialogBuilder.setTitle("Incorrect Details");
                        dialogBuilder.setMessage("Please Enter All Details");
                        dialogBuilder.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog b = dialogBuilder.create();
                        b.show();
                    } else if (mViewPager.getCurrentItem() + 1 < adapter.getCount()) {
                        pos++;
                        mViewPager.setCurrentItem(pos);
                    }


                    if (mViewPager.getCurrentItem() == adapter.getCount() - 1) {
                        ImageView image = (ImageView) findViewById(R.id.conimage);
                        TextView title = (TextView) mViewPager.findViewById(R.id.contitle);
                        TextView price = (TextView) mViewPager.findViewById(R.id.conprice);
                        TextView cond = (TextView) mViewPager.findViewById(R.id.concond);
                        TextView itemloc = (TextView) mViewPager.findViewById(R.id.conloc);
                        TextView postmeth = (TextView) mViewPager.findViewById(R.id.conmeth);
                        TextView postprc = (TextView) mViewPager.findViewById(R.id.conpostprice);
                        TextView rtnaccp = (TextView) mViewPager.findViewById(R.id.conreturn);
                        TextView qty = (TextView) mViewPager.findViewById(R.id.conqty);
                        TextView desc = (TextView) mViewPager.findViewById(R.id.condetail);

                        image.setImageBitmap(bittmap);

                        title.setText(etitemtitle.getText().toString());
                        price.setText("£" + etprice.getText().toString());
                        cond.setText(etcondition.getText().toString());
                        itemloc.setText(etitemlocation.getText().toString());
                        postmeth.setText(etpostmeth.getText().toString());
                        postprc.setText("£" + etpostprc.getText().toString());
                        rtnaccp.setText(rtnaccept.getText().toString());
                        qty.setText(etqty.getText().toString());
                        desc.setText(etdescrip.getText().toString());

                        nextbton.setText("Sell Item");
                        itemtitle = etitemtitle.getText().toString();
                        itemprice = etprice.getText().toString();
                        condition = etcondition.getText().toString();
                        itemLocation = etitemlocation.getText().toString();
                        postagemethod = etpostmeth.getText().toString();
                        postageprice = etpostprc.getText().toString();
                        returnAccept = rtnaccept.getText().toString();
                        quantity = etqty.getText().toString();
                        description = etdescrip.getText().toString();

                        if (bittmap != null) {
                            itemimage = getStringImage(bittmap);
                        }
                        confirm = true;
                    }
                }
            }
        });
    }

    public void uploadImage() {
        String url = "https://selene.hud.ac.uk/kingsman/uploadItem.php";
        StringRequest strreq = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                String id = "";
                String confrimation = "";
                if (response != "Error") {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        JSONArray array = jsonObject.getJSONArray("server_response");
                        JSONObject json = array.getJSONObject(0);

                        id = json.getString("id");
                        confrimation = json.getString("confirm");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                if (confrimation.equals("successful")) {
                    Intent myIntent = new Intent(ctx, SellConfirmActivity.class);
                    myIntent.putExtra("id", id);
                    ctx.startActivity(myIntent);
                } else {
                    android.app.AlertDialog.Builder dialoger = new android.app.AlertDialog.Builder(ctx);
                    dialoger.setTitle("Error");
                    dialoger.setMessage("Please Try Again");
                    dialoger.setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            dialog.dismiss();
                        }
                    });
                    android.app.AlertDialog b = dialoger.create();
                    b.show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {


                Map<String, String> params = new HashMap<>();
                params.put("title", itemtitle);
                params.put("price", itemprice);
                params.put("user", user);
                params.put("cond", condition);
                params.put("location", itemLocation);
                params.put("method", postagemethod);
                params.put("postprice", postageprice);
                params.put("rtnacp", returnAccept);
                params.put("qty", quantity);
                params.put("des", description);
                params.put("image", itemimage);


                return params;
            }
        };

        MySingleton.getInstance(sellActivity.this).addToRequestQue(strreq);
    }

    public String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    private void setupViewPager(ViewPager viewPager) {
        adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new sellcatFragment(), "cat");
        adapter.addFragment(new sellpicFragment(), "pic");
        adapter.addFragment(new selldetailFragment(), "detail");
        adapter.addFragment(new sellconfirmFragment(), "confirm");
        viewPager.setAdapter(adapter);
    }
}
