package com.example.arslan.stradez;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.LayerDrawable;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

import Adapters.BadgeDrawable;

public class ItemActivity extends BaseActivity {

    BadgeDrawable badge;
    String selected;
    String itemid;
    int quantity = 0;
    int taken = 0;
    LayerDrawable icon;
    String cartArray;
    JSONObject jsonObject;
    String resultstr;


    ImageView itemimage;
    TextView itemtitle, itemprice, postprice, postmeth, seller, qty, detail, condition, returnacp, location, postdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_items);

        selected = getIntent().getStringExtra("selected");

        onCreate();

        itemtitle = (TextView) findViewById(R.id.itemtitleac);
        itemprice = (TextView) findViewById(R.id.itemprice);
        postprice = (TextView) findViewById(R.id.postprice);
        postmeth = (TextView) findViewById(R.id.postmethod);
        seller = (TextView) findViewById(R.id.seller);
        detail = (TextView) findViewById(R.id.itemdetail);
        itemimage = (ImageView) findViewById(R.id.itemimageac);
        condition = (TextView) findViewById(R.id.itemcond);
        returnacp = (TextView) findViewById(R.id.itemrtnacp);
        location = (TextView) findViewById(R.id.itemloc);
        postdate = (TextView) findViewById(R.id.postdate);
        qty = (TextView) findViewById(R.id.itemqty);

        new Backw().execute();

    }

    public void onAddtocart(View v) throws JSONException, NullPointerException {

        if (v.getId() == R.id.btnaddcart) {

            SharedPreferences sharedpref2 = getSharedPreferences("cartArray", Context.MODE_PRIVATE);
            String cart = sharedpref2.getString("cartarray", null);

            JSONObject json = new JSONObject();
            JSONArray array = new JSONArray();
            JSONObject jsonObj = jsonObject;
            int pos = 0;
            boolean exists = false;
            if (cart != null) {
                json = new JSONObject(cart);
                array = json.getJSONArray("cart");

                for (int i = 0; i < array.length(); i++) {
                    JSONObject jsonOb = array.getJSONObject(i);
                    if (itemid.equals(jsonOb.getString("ItemID"))) {
                        taken = Integer.parseInt(jsonOb.getString("AddedQty"));
                        jsonObj = jsonOb;
                        pos = i;
                        exists = true;
                        break;
                    }
                }
            }
            if (quantity > taken) {
                taken++;

                SharedPreferences sharedPref = getSharedPreferences("cartcount", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPref.edit();
                int count = sharedPref.getInt("count", 0);
                editor.putInt("count", count + 1);
                editor.apply();

                icon = (LayerDrawable) itemCart.getIcon();
                badge.setBadgeCount(this, icon, String.valueOf(count + 1));

                jsonObj.putOpt("AddedQty", taken);

                if (exists) {
                    array.remove(pos);
                    array.put(pos, jsonObj);
                } else {
                    array.put(jsonObj);
                }

                json.putOpt("cart", array);
                cartArray = json.toString();

                SharedPreferences.Editor editor2 = sharedpref2.edit();
                editor2.putString("cartarray", cartArray);
                editor2.apply();

            } else {
                AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                alertDialog.setTitle("Alert");
                alertDialog.setMessage(" Item Is Not Available ");
                alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                alertDialog.show();
            }
        }
    }

    class Backw extends AsyncTask<Void, Void, String> {

        String json_url;
        String json_string;

        @Override
        protected void onPreExecute() {
            json_url = "https://selene.hud.ac.uk/kingsman/getitem.php";
        }

        @Override
        protected String doInBackground(Void... voids) {

            try {
                URL url = new URL(json_url);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                httpURLConnection.setRequestMethod("POST");
                httpURLConnection.setDoOutput(true);
                httpURLConnection.setDoInput(true);
                OutputStream outputStream = httpURLConnection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String data = URLEncoder.encode("item_id", "UTF-8") + "=" + URLEncoder.encode(selected, "UTF-8");
                bufferedWriter.write(data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                while ((json_string = bufferedReader.readLine()) != null) {
                    stringBuilder.append(json_string + "\n");
                }

                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();

                return stringBuilder.toString();

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    resultstr = result;
                    JSONObject res = new JSONObject(result);
                    JSONArray jsonArray = res.getJSONArray("server_response");
                    jsonObject = jsonArray.getJSONObject(0);
                    itemid = jsonObject.getString("ItemID");
                    String ti = jsonObject.getString("Title");
                    String pr = jsonObject.getString("Price");
                    String popr = jsonObject.getString("postprice");
                    String pome = jsonObject.getString("method");
                    String cond = jsonObject.getString("Condition");
                    String rtnacp = jsonObject.getString("ReturnAccepted");
                    String loc = jsonObject.getString("location");
                    String postdte = jsonObject.getString("Postdate");
                    final String sell = jsonObject.getString("Seller");
                    String des = jsonObject.getString("Descrip");
                    quantity = Integer.parseInt(jsonObject.getString("Qty"));

                    String image = jsonObject.getString("image");

                     if(image != null){
                        Picasso.with(getParent())
                                .load(image)
                                .into(itemimage);
                     }


                    itemtitle.setText(ti);
                    itemprice.setText("£" + pr);
                    postprice.setText("£" + popr);
                    postmeth.setText(pome);
                    seller.setText(sell);
                    detail.setText(des);
                    qty.setText(String.valueOf(quantity));
                    condition.setText(cond);
                    returnacp.setText(rtnacp);
                    location.setText(loc);
                    postdate.setText(postdte);

                    seller.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Intent mintent = new Intent(getBaseContext(), ProfileActivity.class);
                            mintent.putExtra("seller", sell);
                            startActivity(mintent);
                        }
                    });

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

        }
    }


}

