package Database;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.example.arslan.stradez.SellHistoryActivity;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

/**
 * ItemDB class used to delete item or to update order delivery detail on the database
 * Created by Arslan on 24/02/2018.
 */

public class ItemDB extends AsyncTask<String, Void, String> {

    String itemid;
    Context ctx;

    public ItemDB(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPreExecute() {
    }

    @Override
    protected String doInBackground(String... params) {

        String urll = "https://selene.hud.ac.uk/kingsman/deleteitem.php";
        String method = params[0];
        itemid = params[1];
        if (method.equals("delivered")) {
            urll = "https://selene.hud.ac.uk/kingsman/delivered.php";
        }
        try {
            URL url = new URL(urll);
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
            String data = URLEncoder.encode("id", "UTF-8") + "=" + URLEncoder.encode(itemid, "UTF-8");
            bufferedWriter.write(data);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.close();
            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String response = bufferedReader.readLine();
            bufferedReader.close();
            inputStream.close();
            httpURLConnection.disconnect();
            return response;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        super.onProgressUpdate(values);
    }

    /**
     * After the ececution onPostExecute call restart method in SellHistory activity
     * and parse result
     *
     * @param result
     */
    @Override
    protected void onPostExecute(String result) {
        ((SellHistoryActivity) ctx).restart(result);

    }
}