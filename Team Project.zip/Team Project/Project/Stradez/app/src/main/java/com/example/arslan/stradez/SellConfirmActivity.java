package com.example.arslan.stradez;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SellConfirmActivity extends BaseActivity {

    String itemid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        itemid = getIntent().getStringExtra("id");
        setContentView(R.layout.activity_sell_confirm);

        onCreate();
    }

    public void onViewItem(View v) {
        Intent myIntent = new Intent(SellConfirmActivity.this, ItemActivity.class);
        myIntent.putExtra("selected", itemid);
        startActivity(myIntent);
    }
}
