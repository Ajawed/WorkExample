package com.example.arslan.stradez;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.widget.Toast;

import Adapters.SectionsPageAdapter;
import Fragments.sellcancelfragment;
import Fragments.sellreturnfragment;
import Fragments.itemonsellfragment;
import Fragments.ordersfragment;

public class SellHistoryActivity extends BaseActivity {

    private static final String TAG = "SellHistory";

    private SectionsPageAdapter mSecPageAdap;

    private ViewPager mViewPager;
    public String username;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell_history);
        SharedPreferences sharedPref = getSharedPreferences("Userinfo", Context.MODE_PRIVATE);
        username = sharedPref.getString("username", "");

        if (username == "") {
            Intent myIntent = new Intent(SellHistoryActivity.this, Login_RegisterActivity.class);
            startActivity(myIntent);
        }

        mSecPageAdap = new SectionsPageAdapter(getSupportFragmentManager());

        mViewPager = (ViewPager) findViewById(R.id.container);
        setupViewPager(mViewPager);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);
        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);

        onCreate();

    }

    public void restart(String result) {
        setupViewPager(mViewPager);
        Toast.makeText(this, result, Toast.LENGTH_LONG).show();

    }

    private void setupViewPager(ViewPager viewPager) {
        SectionsPageAdapter adapter = new SectionsPageAdapter(getSupportFragmentManager());
        adapter.addFragment(new itemonsellfragment(), "Items On Sell");
        adapter.addFragment(new ordersfragment(), "Orders");
        adapter.addFragment(new sellreturnfragment(), "Returned Items");
        adapter.addFragment(new sellcancelfragment(), "Canceled Items");
        viewPager.setAdapter(adapter);
    }
}
