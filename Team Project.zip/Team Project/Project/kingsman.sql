-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 16, 2018 at 11:02 AM
-- Server version: 5.7.19-0ubuntu0.16.04.1-log
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kingsman`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `AddressID` int(6) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `HouseNo` varchar(5) NOT NULL,
  `Street` varchar(100) NOT NULL,
  `CityTown` varchar(50) NOT NULL,
  `Country` varchar(50) NOT NULL,
  `Postcode` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`AddressID`, `Username`, `HouseNo`, `Street`, `CityTown`, `Country`, `Postcode`) VALUES
(1, 'AK475', '52B', 'New Street', 'Huddersfield', 'England', 'HD1 9JN'),
(2, 'FessilBoy', '34', 'Church Street', 'Huddersfield', 'United Kingdom', 'HD1 4TR'),
(3, 'Manpreet1', '80', 'Bradford Road', 'Huddersfield', 'United Kingdom', 'HD1 6JE'),
(4, 'Matty1', '86', 'Birstall Lane', 'Drighlington, Bradford ', 'United Kingdom', 'BD11 1JJ'),
(5, 'RafiqZ', '86', 'Clayton Road', 'Bradford', 'United Kingdom', 'BD7 2LY'),
(7, 'JunaidJ', '48', 'New Street', 'Huddersfield', 'England', 'Hd2 9Pl'),
(9, 'Asad22', '45', 'HollyTerrace', 'Bradford', 'England', 'BD7 9kn'),
(10, 'Asad25', '25', 'new', 'new', 'new', 'new');

-- --------------------------------------------------------

--
-- Table structure for table `cancelled_item`
--

CREATE TABLE `cancelled_item` (
  `CancelID` int(6) NOT NULL,
  `OrderID` int(6) NOT NULL,
  `Canceldate` date NOT NULL,
  `Reason` varchar(1000) NOT NULL,
  `Quantity` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cancelled_item`
--

INSERT INTO `cancelled_item` (`CancelID`, `OrderID`, `Canceldate`, `Reason`, `Quantity`) VALUES
(7, 3, '2018-03-15', 'Not Needed', 1),
(8, 8, '2018-03-15', 'Not Needed', 1),
(9, 10, '2018-03-15', 'Not Needed', 7),
(11, 37, '2018-03-16', 'Not Needed', 2),
(12, 39, '2018-03-16', 'Not Needed', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `FeedbackID` int(6) NOT NULL,
  `Tile` int(11) NOT NULL,
  `Message` text NOT NULL,
  `FeedbackType` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `ItemID` int(6) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `Image` varchar(100) DEFAULT NULL,
  `Condition` varchar(100) NOT NULL,
  `Price` double(11,2) NOT NULL,
  `ItemLocation` varchar(50) NOT NULL,
  `DeliveryMethod` varchar(100) NOT NULL,
  `PostagePrice` double NOT NULL,
  `ReturnAccepted` varchar(100) NOT NULL,
  `PostDate` date DEFAULT NULL,
  `Quantity` int(3) NOT NULL,
  `Removed` varchar(5) NOT NULL DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`ItemID`, `Username`, `Title`, `Description`, `Image`, `Condition`, `Price`, `ItemLocation`, `DeliveryMethod`, `PostagePrice`, `ReturnAccepted`, `PostDate`, `Quantity`, `Removed`) VALUES
(1, 'RafiqZ', 'APPLE MacBook Pro 13" - Space Grey (2017)', 'MacOS\r\nIntel® Core™ i5 processor\r\nRAM: 8 GB / Storage: 256 GB SSD\r\nGraphics: Intel® Iris™\r\nRetina display', 'https://selene.hud.ac.uk/kingsman/uploads/1.jpg', 'Mint', 1449.00, 'University of Huddersfield ', 'Pickup', 0, 'Yes', '2018-01-19', 0, 'No'),
(2, 'RafiqZ', 'APPLE iPhone 6 - 32 GB, Space Grey', 'iOS 8\r\n4.7" Retina HD display\r\n8 MP camera & Full HD recording\r\nApple A8 processor\r\nBattery capacity: 1810 mAh', 'https://selene.hud.ac.uk/kingsman/uploads/2.jpg', 'Used', 329.99, 'University Of Huddersfield ', 'Pickup', 0, 'Yes', '2018-02-06', 32, 'No'),
(3, 'FessilBoy', 'Encyclopedia of Cryptography and Security', 'The Encyclopedia of Cryptography and Security is a comprehensive work on Cryptography for both information security professionals and experts in the fields of Computer Science, Applied Mathematics, Engineering, Information Theory, Data Encryption.', 'https://selene.hud.ac.uk/kingsman/uploads/3.jpg', 'Used', 15.99, 'University of Huddersfield', 'Pickup', 0, 'No', '2018-02-03', 1, 'No'),
(4, 'FessilBoy', 'APPLE Lightning to USB-C Cable - 2 m', 'Compatible with Apple Lightning devices\r\nLightning & USB connectors', 'https://selene.hud.ac.uk/kingsman/uploads/4.jpg', 'Good', 10.99, 'HD1 4TR', 'Mail', 3.99, 'Yes', '2018-01-09', 0, 'No'),
(5, 'AK475', 'Simple Cutlery Sets', 'This 24-piece Venice cutlery set from the Simple Value range would be ideal for a student living at university.', 'https://selene.hud.ac.uk/kingsman/uploads/5.jpg', 'Mint', 2.99, 'BD7 1QG', 'Mail', 0.99, 'Yes', '2018-01-04', 0, 'No'),
(6, 'Manpreet1', 'Pulsar Gents Digital Chronograph Rubber Strap Watch', 'New without tags: A brand-new, unused and unworn item that is not in its original retail packaging or may be missing its original retail packaging materials (such as the original box or bag).', 'https://selene.hud.ac.uk/kingsman/uploads/6.jpg', 'New', 49.99, 'HD1 6JE', 'Hermes', 3.99, 'Yes', '2018-02-21', 2, 'No'),
(7, 'Matty1', 'Lock and & Lock Plastic Food Storage Containers', 'New: A brand-new, unused, unopened and undamaged item in original retail packaging (where packaging is applicable).', 'https://selene.hud.ac.uk/kingsman/uploads/7.jpg', 'New', 3.99, 'BD11 1JJ', 'Hermes', 0.99, 'Yes', '2018-01-24', 2, 'No'),
(8, 'AK475', 'Casio FX-83GTPLUS Scientific Calculator', 'The Casio FX83GTPLUS is the UK\'s best-selling scientific calculator\r\nAllowed in every UK exam where a calculator can be used and suitable for use from Key Stage 3 4 and above and recommended for GCSE, A/AS level,Standard and Higher\r\nIt has 260 functions and is battery powered and has a large 10+2 displaySuitable for university students\r\nIncludes a timetable\r\nLength : 150 mm\r\nColour: Dark Green', 'https://selene.hud.ac.uk/kingsman/uploads/9.jpg', 'New', 3.99, 'BD7 1QG', 'Hermes', 1.99, 'Yes', '2018-01-17', 1, 'No'),
(9, 'Manpreet1', 'Casio FX-85GTPLUS Scientific Calculator', 'Colour: Black\r\nModel: Casio\r\nProduct Line: Casio', 'https://selene.hud.ac.uk/kingsman/uploads/9.jpg', 'Used', 5.99, 'University Of Huddersfield ', 'Pickup', 0, 'Yes', '2018-02-01', 1, 'No'),
(10, 'Matty1', 'Oxford Office Wirebound Notebooks Soft Board Cover A5', 'A5 sized notebooks perfect for anyone to use with the intentions of writing anything on them.', 'https://selene.hud.ac.uk/kingsman/uploads/10.png', 'New', 15.99, 'BD11 1JJ', 'Hermes', 2.99, 'Yes', '2018-01-26', 2, 'No'),
(11, 'Matty1', 'Pack of 12 White plates', '12 White plates that can be put in the microwave or oven and are in good condition', 'https://selene.hud.ac.uk/kingsman/uploads/11.jpg', 'Good', 5.00, 'University of Huddersfield', 'Pickup', 1.99, 'No', '2018-02-14', 1, 'No'),
(12, 'Manpreet1', 'French Blue 100% Linen Bed Sheet Set', 'Comfortable, brand new bed sheets', 'https://selene.hud.ac.uk/kingsman/uploads/12.jpg', 'New', 7.99, 'HD1 6JE', 'Hermes', 0, 'Yes', '2018-03-01', 2, 'No'),
(13, 'Manpreet1', '16" Expendable Fan', 'Brand new 16" expendable fan that works perfectly.', 'https://selene.hud.ac.uk/kingsman/uploads/13.jpg', 'New', 13.99, 'HD1 6JE', 'Pickup', 0, 'Yes', '2018-03-05', 0, 'No'),
(14, 'FessilBoy', 'Apple Beats headphones', 'Good condition headphones, that output a quality sound.', 'https://selene.hud.ac.uk/kingsman/uploads/14.jpg', 'Good', 150.00, 'HD1 4TR', 'Royal Mail (Recorded delivery)', 5.99, 'Yes', '2018-03-06', 0, 'No'),
(15, 'AK475', 'XB1 S 250GB', 'New: A brand-new, unused, unopened and undamaged item in original retail packaging (where packaging is applicable).', 'https://selene.hud.ac.uk/kingsman/uploads/15.jpg', 'New', 209.99, 'BD5 1QG', 'Royal Mail(Recorded Delivery)', 5.99, 'Yes', '2018-03-06', 6, 'No'),
(16, 'RafiqZ', 'Anker International Stationary Mechanical Pencil (Pack of 5)', 'A brand-new, unused, unopened and undamaged item.', 'https://selene.hud.ac.uk/kingsman/uploads/16.jpg', 'New', 3.99, 'University of Huddersfield', 'Pickup', 0, 'No', '2018-03-06', 2, 'No'),
(17, 'AK475', 'White 1.7 Litre 2200w Cordless Fast Boil Electric Jug Kettle', 'Used Kettle however still works really well.', 'https://selene.hud.ac.uk/kingsman/uploads/17.jpg', 'Used', 7.99, 'University of Huddersfield', 'Pickup', 0, 'No', '2018-03-07', 0, 'No'),
(18, 'FessilBoy', '2L Hot water bottle', 'A used hot water bottle, that is still in good condition', 'https://selene.hud.ac.uk/kingsman/uploads/18.jpg', 'good', 2.99, 'HD1 4TR', 'Royal Mail', 1.99, 'Yes', '2018-03-08', 0, 'No'),
(19, 'AK475', '5 Litre Portable Small Mini Fridge', 'Used 4 litre mini fridge ideal for university dorm rooms', 'https://selene.hud.ac.uk/kingsman/uploads/19.jpg', 'Good', 20.00, 'BD7 1QG', 'Royal Mail (Recorded Delivery)', 3.99, 'No', '2018-03-08', 0, 'No'),
(20, 'FessilBoy', 'Plastic Storage Boxes Clear Box With Lids', 'Plastic Storage boxes x 12', 'https://selene.hud.ac.uk/kingsman/uploads/20.jpg', 'Good', 7.99, 'HD1 4TR', 'Royal Mail', 2.99, 'Yes', '2018-03-09', 8, 'No'),
(51, 'Ak475', 'uhnlkaasx', 'adnasidnlsakndlkasndiasodjqpowdiohqwihqiwdnindiansld', 'https://selene.hud.ac.uk/kingsman/uploads/51.jpg', 'kbiubku', 20.00, 'ubukbkj', 'kubkjbk', 20, 'Yes', '2018-03-16', 20, 'No'),
(52, 'Ak475', 'gvjvh', 'jbkjbknk', 'https://selene.hud.ac.uk/kingsman/uploads/52.jpg', 'dfgdgf', 25.00, 'h hj hjb hj', 'gv g g g', 7676, 'Yes', '2018-03-16', 7, 'No');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `OrderID` int(6) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `ItemID` int(6) NOT NULL,
  `OrderDate` date NOT NULL,
  `Quantity` int(3) NOT NULL,
  `Delivered` varchar(3) NOT NULL DEFAULT 'No',
  `ReturnedorCancelled` varchar(3) NOT NULL DEFAULT 'No'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`OrderID`, `Username`, `ItemID`, `OrderDate`, `Quantity`, `Delivered`, `ReturnedorCancelled`) VALUES
(1, 'Manpreet1', 3, '2018-02-05', 1, 'No', 'No'),
(2, 'AK475', 14, '2018-03-01', 1, 'No', 'Yes'),
(3, 'AK475', 4, '2018-02-05', 1, 'No', 'Yes'),
(4, 'Matty1', 5, '2018-02-06', 1, 'Yes', 'No'),
(5, 'RafiqZ', 10, '2018-02-06', 1, 'No', 'Yes'),
(6, 'AK475', 1, '2018-03-02', 2, 'No', 'Yes'),
(7, 'AK475', 6, '2018-02-07', 2, 'No', 'No'),
(8, 'Manpreet1', 7, '2018-02-08', 1, 'No', 'Yes'),
(9, 'Manpreet1', 8, '2018-02-08', 1, 'Yes', 'Yes'),
(10, 'Matty1', 9, '2018-02-09', 1, 'No', 'Yes'),
(36, 'AK475', 5, '2018-03-15', 1, 'Yes', 'No'),
(37, 'AK475', 12, '2018-03-16', 2, 'No', 'Yes'),
(38, 'AK475', 19, '2018-03-16', 1, 'Yes', 'No'),
(39, 'AK475', 15, '2018-03-16', 1, 'No', 'Yes'),
(40, 'Ak475', 20, '2018-03-16', 1, 'No', 'No');

-- --------------------------------------------------------

--
-- Table structure for table `paypal_account`
--

CREATE TABLE `paypal_account` (
  `PaypalAccountID` int(6) NOT NULL,
  `PaypalName` varchar(100) NOT NULL,
  `Username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `returned_item`
--

CREATE TABLE `returned_item` (
  `ReturnID` int(6) NOT NULL,
  `OrderID` int(6) NOT NULL,
  `ReturnDate` date NOT NULL,
  `Reason` text NOT NULL,
  `Quantity` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `returned_item`
--

INSERT INTO `returned_item` (`ReturnID`, `OrderID`, `ReturnDate`, `Reason`, `Quantity`) VALUES
(1, 5, '2018-02-07', 'I purchased this product and thought it was something else.', 1),
(2, 9, '2018-02-08', 'Seller lied about the condition of product.', 1),
(3, 6, '2018-02-16', 'Product no longer working ', 1),
(16, 2, '2018-03-16', 'Faulty', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Username` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `PhoneNumber` varchar(16) NOT NULL,
  `JoinDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Username`, `FirstName`, `LastName`, `Email`, `Password`, `PhoneNumber`, `JoinDate`) VALUES
('AK475', 'Akeel', 'Latif', 'u1667656@unimail.hud.ac.uk', '$2y$10$KRSZ3VVb0s7Jn5n/mdscV.CewB5eQjtilfVIJrSZa1L8tuifhvZue', '01484355798', '2018-02-01'),
('Arslanjawed', 'arslan', 'jawed', 'U1655393@unimail.hud.ac.uk', '$2y$10$XhNr/0MmZ5CjLXF8arNTc.VwCY3jCq3B38qBLBJG60TQPCqK5ekyu', '07552369963', '2018-03-12'),
('Asad22', 'Asad', 'Aslam', 'u1665825@unimail.hud.ac.uk', '$2y$10$UWI3rv4hNs7XBY7j83h.deLx4Cg2PumLnxs6gWFToQG6DEHEOGno.', '07558525585', '2018-03-15'),
('FessilBoy', 'Wasil', 'Ashan', 'U1659540@unimail.hud.ac.uk', 'HUj1e3drs', '755164365', '2018-02-04'),
('JunaidJ', 'Junaid', 'Jamshed', 'U1661987@unimail.hud.ac.uk', '$2y$10$VgXV067mqTPAUQWlFUhpBu/3iu4cOuNMOhnuDF9BUtsMF9y5aFdA6', '07552505505', '2018-03-12'),
('Kasim97', 'Kasim', 'Ali', 'U1647393@unimail.hud.ac.uk', '$2y$10$T8q2BElgtCUrYYXa9ta6JeMFtQlkuCfujcmsj8HYHntzr1lqKhAie', '0785256369808752', '2018-03-14'),
('KasimA', 'Kasim', 'Ali', 'U1655383@unimail.hud.ac.uk', '$2y$10$sWUS04SAo9qslfoj8g4uXOdSzXsz28dpsEZbQ1QQEH.j62SR8qKvS', '0744562885606253', '2018-03-12'),
('Manpreet1', 'Manpreet', 'Singh', 'U1667656@hud.ac.uk', 'pass', '744564', '2018-02-01'),
('Matty1', 'Matthew ', 'Wray', 'U1653411', 'HjJkHy736', '784463579', '2018-02-04'),
('RafiqZ', 'Zain', 'Rafiq', 'U1651673@unimail.hud.ac.uk', 'Lwnehns01', '787653892', '2018-02-04');

-- --------------------------------------------------------

--
-- Table structure for table `user_feedback`
--

CREATE TABLE `user_feedback` (
  `FeedbackID` int(6) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`AddressID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `cancelled_item`
--
ALTER TABLE `cancelled_item`
  ADD PRIMARY KEY (`CancelID`),
  ADD UNIQUE KEY `OrderID` (`OrderID`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`FeedbackID`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`ItemID`),
  ADD KEY `Username` (`Username`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`OrderID`),
  ADD KEY `ItemID` (`ItemID`),
  ADD KEY `Username` (`Username`);

--
-- Indexes for table `paypal_account`
--
ALTER TABLE `paypal_account`
  ADD PRIMARY KEY (`PaypalAccountID`),
  ADD KEY `Username` (`Username`);

--
-- Indexes for table `returned_item`
--
ALTER TABLE `returned_item`
  ADD PRIMARY KEY (`ReturnID`),
  ADD KEY `OrderID` (`OrderID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Username`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- Indexes for table `user_feedback`
--
ALTER TABLE `user_feedback`
  ADD PRIMARY KEY (`FeedbackID`,`Username`),
  ADD KEY `FeedbackID` (`FeedbackID`),
  ADD KEY `Username` (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `AddressID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `cancelled_item`
--
ALTER TABLE `cancelled_item`
  MODIFY `CancelID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `ItemID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `OrderID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;
--
-- AUTO_INCREMENT for table `returned_item`
--
ALTER TABLE `returned_item`
  MODIFY `ReturnID` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
