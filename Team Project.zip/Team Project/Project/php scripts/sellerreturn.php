<?php
require_once "conn.php";

$query = $_POST["query"]; 

$qry = "SELECT * FROM returned_item LEFT Join `order` ON `order`.`OrderID` = returned_item.OrderID 
LEFT JOIN item ON item.ItemID = `order`.`ItemID`  WHERE item.Username = '$query'
GROUP BY `order`.`ItemID`;";

$result = mysqli_query($conn, $qry);

$response = array();

while($row = mysqli_fetch_array($result)){

array_push($response,array("returnid"=>$row[0],"orderid"=>$row[1],"returndate"=>$row[2],"reason"=>$row[3],"quantity"=>$row[4],
"username"=>$row[6],"orderdate"=>$row[8],"seller"=>$row[13],"title"=>$row[14], "image"=>$row[16],
"price"=>$row[18]));
}

echo json_encode(array("server_response"=>$response));

mysqli_close($conn);
?>