<?php
require_once "conn.php";
$user_name = $_POST["login_name"];  
$user_pass = $_POST["login_pass"]; 
$mysql_qry = "select Username, Password from user where Username = '$user_name';";
$result = mysqli_query($conn, $mysql_qry);

if(mysqli_num_rows($result)>0){

$row = mysqli_fetch_array($result);

if(password_verify($user_pass, $row[1])) {	
echo "success";
	}
}	
else{
	echo "Login Failed \n Incorrect Username or Password";
}

mysqli_close($conn);
?>