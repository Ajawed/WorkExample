<?php
require_once "conn.php"; 

$sql ="SELECT ItemID FROM `item` ORDER BY `item`.`ItemID` DESC"; 
$res = mysqli_query($conn,$sql);
$row = mysqli_fetch_array($res);
$id = $row[0]+1;
 
$image = $_POST['image'];
$title = $_POST['title'];
$user_name = $_POST['user'];
$des = $_POST['des'];
$con =  $_POST['cond'];
$price = $_POST['price'];
$loc = $_POST['location'];
$meth = $_POST['method'];
$postprice = $_POST['postprice'];
$returnaccepted =$_POST['rtnacp'];
$qty = $_POST['qty'];
$date =  date("Y/m/d"); 
 
$path = "uploads/$id.jpg";

$response = array();
 
$actualpath = "https://selene.hud.ac.uk/kingsman/$path";

$sql = "INSERT INTO  item (Username,Title,Description,Image,`Condition`,Price,ItemLocation,DeliveryMethod,PostagePrice,ReturnAccepted,Postdate,Quantity)  
values('$user_name', '$title','$des', '$actualpath', '$con', '$price','$loc','$meth','$postprice','$returnaccepted','$date','$qty');";

array_push($response,array("id"=>$id,"confirm"=>"successful"));

if(mysqli_query($conn,$sql)){
  $decoded = base64_decode($image);
 file_put_contents($path, $decoded);
echo json_encode(array("server_response"=>$response));
 }
else{
echo "Error";
}
mysqli_close($conn);

?>