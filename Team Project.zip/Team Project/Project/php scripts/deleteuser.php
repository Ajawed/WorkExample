<?php
require_once "conn.php";

$user_name= $_POST["user_name"]; 


$sql_query = "DELETE FROM `user` WHERE `user`.`Username` = '$user_name';";

if($conn->query($sql_query)){
echo "Account Terminated";
}
else{
echo "Failed \n Try Again";
}

mysqli_close($conn);
?>
