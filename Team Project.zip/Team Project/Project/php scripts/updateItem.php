<?php
  
 require_once "conn.php";

$id = $_POST['itemid'];
$title = $_POST['title'];
$des = $_POST['des'];
$con =  $_POST['cond'];
$price = $_POST['price'];
$loc = $_POST['location'];
$meth = $_POST['method'];
$postprice = $_POST['postprice'];
$returnaccepted =$_POST['rtnacp'];
$qty = $_POST['qty'];


$sql_query = "UPDATE item
SET item.Title = '$title', item.Description = '$des', item.Condition = '$con', item.Price = '$price', item.ItemLocation = '$loc', 
 item.DeliveryMethod = '$meth', item.PostagePrice = '$postprice', item.ReturnAccepted = '$returnaccepted', item.Quantity = '$qty' 
WHERE item.ItemID = '$id';";

if($conn->query($sql_query)){
echo "Item Modified";
}
else{
echo "Error \n Please Try Again";
}
mysqli_close($conn);

 ?>