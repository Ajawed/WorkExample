<?php
$db_name="kingsman";
$mysql_username="kingsman";
$mysql_password="KM97owtfit";
$server_name="localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password, $db_name);
?> 