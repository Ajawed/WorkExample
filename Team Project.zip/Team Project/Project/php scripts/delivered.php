<?php
require_once "conn.php";

$order_id = $_POST["id"]; 


$sql_query = "UPDATE `order`
SET `order`.Delivered = 'Yes'
WHERE `order`.OrderID = '$order_id';";

if($conn->query($sql_query)){
echo "Order Delivered";
}
else{
echo "Error \n Please Try Again";
}
mysqli_close($conn);
?>