<?php
require_once "conn.php";
  
$user = $_POST["user_name"];
$itemid =  $_POST["itemid"];
$qty =  $_POST["qty"];
$date =  date("Y/m/d");

$qry = "select Quantity from item where item.ItemID = '$itemid';";

$result = mysqli_query($conn, $qry);
$row = mysqli_fetch_array($result);

$quantity = $row[0];

if($quantity < $qty){
echo "Not Successfull";
}
else{
$quantity = $quantity - $qty;
$sql_query2 = "UPDATE item
SET item.Quantity = '$quantity' 
WHERE item.ItemID = '$itemid';";

$conn->query($sql_query2);

$sql_query = "INSERT INTO  `order`(Username,ItemID,OrderDate,Quantity)  values('$user','$itemid', '$date', '$qty');";
$conn->query($sql_query);
echo "Successfull";
}
mysqli_close($conn);
?>