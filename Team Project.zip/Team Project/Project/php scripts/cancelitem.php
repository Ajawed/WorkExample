<?php
require_once "conn.php";

$order_id = $_POST["order_id"];
$reason =  $_POST["reason"];
$qty = $_POST["qty"];
$date =  date("Y/m/d");

$sql_query = "INSERT INTO  `cancelled_item`(OrderID,Canceldate,Reason,Quantity)  values('$order_id','$date', '$reason', '$qty');";
$sql_query2 = "UPDATE `order` SET `order`.ReturnedorCancelled = 'Yes' WHERE `order`.`OrderID` = '$order_id';";
if($conn->query($sql_query) &&
$conn->query($sql_query2)){
echo "Order Cancelled";
}
else{
echo "Error \n Please Try Again";
}

mysqli_close($conn);
?>