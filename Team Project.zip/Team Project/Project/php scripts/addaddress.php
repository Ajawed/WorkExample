 <?php  
 require_once "conn.php";  
 $houseno =  $_POST["house_no"];
 $street = $_POST["street"]; 
 $user_name = $_POST["user_name"];
 $citytown = $_POST["city"];
 $country = $_POST["country"]; 
 $postcode =  $_POST["postcode"];

$sql_query = "INSERT INTO  address(Username,HouseNo,Street,CityTown,Country,Postcode)  values('$user_name', '$houseno','$street', '$citytown', '$country', '$postcode');";
if($conn->query($sql_query)){
echo "Address Added";
}
else{
echo "Error \n Please Try Again";
}
mysqli_close($conn);

 ?> 