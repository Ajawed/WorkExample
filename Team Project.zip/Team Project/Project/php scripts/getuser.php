<?php
require_once "conn.php";

$user_name = $_POST["user_name"]; 

$qry = "SELECT * FROM `user` LEFT JOIN address ON user.Username = address.Username where user.Username = '$user_name' GROUP BY user.Username;";

$result = mysqli_query($conn, $qry);

$response = array();

$row = mysqli_fetch_array($result);

array_push($response,array("username"=>$row[0],"firstname"=>$row[1],"surname"=>$row[2],"email"=>$row[3], "phone"=>$row[5],"joindate"=>$row[6],"AddressID"=>$row[7],"houseno"=>$row[9],"street"=>$row[10],"city"=>$row[11],"country"=>$row[12],"postcode"=>$row[13]));

echo json_encode(array("server_response"=>$response));

mysqli_close($conn);
?>