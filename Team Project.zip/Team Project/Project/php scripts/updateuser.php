<?php  
 require_once "conn.php";

 $fname =  $_POST["first_name"];
 $sname = $_POST["sur_name"]; 
 $user_name = $_POST["user_name"];
 $phnum = $_POST["phone_number"]; 
 $user_pass =  $_POST["user_pass"];

$hash_pass = password_hash($user_pass, PASSWORD_DEFAULT);
$sql_query = "UPDATE user
SET user.FirstName = '$fname', user.LastName = '$sname', user.PhoneNumber = '$phnum', user.Password = '$hash_pass' 
WHERE user.Username = '$user_name';";

if($conn->query($sql_query)){
echo"Details Modified";
}
else{
echo "Error \n Please Try Again";
}
mysqli_close($conn);

 ?>