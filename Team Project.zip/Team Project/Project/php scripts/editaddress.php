<?php  
 require_once "conn.php";

 $houseno =  $_POST["house_no"];
 $street = $_POST["street"]; 
 $user_name = $_POST["user_name"];
 $citytown = $_POST["city"];
 $country = $_POST["country"]; 
 $postcode =  $_POST["postcode"];

$sql_query = "UPDATE address
SET address.HouseNo = '$houseno', address.Street = '$street', address.CityTown = '$citytown', address.Country = '$country', address.Postcode = '$postcode' 
WHERE address.Username = '$user_name';";

if($conn->query($sql_query)){
echo "Address Modified";
}
else{
echo "Error \n Please Try Again";
}
mysqli_close($conn);

 ?>