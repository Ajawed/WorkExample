<?php
require_once "conn.php";

$query = $_POST["query"]; 

$qry = "SELECT * FROM `order` LEFT Join item ON `order`.`ItemID` = item.ItemID WHERE `order`.Username = '$query' AND `order`.`ReturnedorCancelled`= 'No'
GROUP BY `order`.`ItemID`;";

$result = mysqli_query($conn, $qry);

$response = array();

while($row = mysqli_fetch_array($result)){

array_push($response,array("orderid"=>$row[0],"username"=>$row[1],"orderdate"=>$row[3],
"quantity"=>$row[4],"delivered"=>$row[5],
"itemid"=>$row[7],"seller"=>$row[8],
"title"=>$row[9],"image"=>$row[11],"price"=>$row[13],"returnaccepted"=>$row[17]));

}

echo json_encode(array("server_response"=>$response));

mysqli_close($conn);
?>