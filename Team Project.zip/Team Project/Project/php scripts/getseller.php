<?php
require_once "conn.php";

$user_name = $_POST["user_name"]; 

$qry = "SELECT Username, FirstName, LastName, PhoneNumber, Email, JoinDate FROM `user` where Username = '$user_name';";

$qry2 = "SELECT Postcode FROM `address` where Username = '$user_name';";

$result = mysqli_query($conn, $qry);
$result2 = mysqli_query($conn, $qry2);

$response = array();

$row = mysqli_fetch_array($result);
$row2 = mysqli_fetch_array($result2);

array_push($response,array("username"=>$row[0],"firstname"=>$row[1],"surname"=>$row[2],"phone"=>$row[3],"email"=>$row[4],"joindate"=>$row[5],"postcode"=>$row2[0]));

echo json_encode(array("server_response"=>$response));

mysqli_close($conn);
?>