<?php
require_once "conn.php";

$item_id = $_POST["id"]; 


$sql_query = "UPDATE item
SET item.Removed = 'Yes', item.Quantity = '0'
WHERE item.ItemID = '$item_id';";

if($conn->query($sql_query)){
echo "Item Removed";
}
else{
echo "Item Not Removed \n Please Try Again";
}
mysqli_close($conn);
?>