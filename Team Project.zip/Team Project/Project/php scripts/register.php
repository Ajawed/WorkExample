 <?php  
 require_once "conn.php";  
 $fname =  $_POST["first_name"];
 $sname = $_POST["sur_name"]; 
 $user_name = $_POST["user_name"];
 $email = $_POST["email"];
 $phnum = $_POST["phone_number"]; 
 $user_pass =  $_POST["user_pass"];
 $date =  date("Y/m/d");

  	$sql_u = "SELECT * FROM user WHERE Username='$user_name'";
  	$sql_e = "SELECT * FROM user WHERE Email='$email'";
  	$res_u = mysqli_query($conn, $sql_u);
  	$res_e = mysqli_query($conn, $sql_e);

  	if (mysqli_num_rows($res_u) > 0) {
  	  echo "Sorry... username already taken"; 	
  	}else if(mysqli_num_rows($res_e) > 0){
  	  echo "Sorry... email already taken"; 	
  	}else{
          $hash_pass = password_hash($user_pass, PASSWORD_DEFAULT);
          $sql_query = "insert into user() values('$user_name','$fname', '$sname', '$email', '$hash_pass', '$phnum', '$date');";
          if($conn->query($sql_query)){
           echo "success";
              }
           else{
               echo "Failed";
            }
  	}

mysqli_close($conn);
 

 ?> 