<?php
require_once "conn.php";

$query = $_POST["query"]; 

$qry = "SELECT * FROM `item` WHERE item.Username = '$query' AND item.Quantity > 0;";

$result = mysqli_query($conn, $qry);

$response = array();

while($row = mysqli_fetch_array($result)){

array_push($response,array("itemid"=>$row[0],"username"=>$row[1],
"title"=>$row[2],"description"=>$row[3],"image"=>$row[4],"condition"=>$row[5],"price"=>$row[6],
"itemlocation"=>$row[7],"postage"=>$row[8],"postprice"=>$row[9],"returnaccepted"=>$row[10]
,"postdate"=>$row[11], "qty"=>$row[12]));

}

echo json_encode(array("server_response"=>$response));

mysqli_close($conn);
?>