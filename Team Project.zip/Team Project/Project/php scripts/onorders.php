<?php
require_once "conn.php";

$query = $_POST["query"]; 

$qry = "SELECT * FROM `order` 
LEFT Join item ON `order`.`ItemID` = item.ItemID 
LEFT JOIN address ON `order`.Username = address.Username 
LEFT JOIN user ON `order`.`Username` = user.Username
WHERE `order`.`ReturnedorCancelled`= 'No' AND item.Username = '$query';";

$result = mysqli_query($conn, $qry);

$response = array();

while($row = mysqli_fetch_array($result)){

array_push($response,array("orderid"=>$row[0],"buyer"=>$row[1],"orderdate"=>$row[3],
"quantity"=>$row[4],"delivered"=>$row[5],
"itemid"=>$row[7], "title"=>$row[9],"image"=>$row[11],"price"=>$row[13], "deliverymethod"=>$row[15], 
"houseno"=>$row[23],"street"=>$row[24],"city"=>$row[25],"country"=>$row[26],"postcode"=>$row[27],"phone"=>$row[33] ));

}

echo json_encode(array("server_response"=>$response));

mysqli_close($conn);
?>