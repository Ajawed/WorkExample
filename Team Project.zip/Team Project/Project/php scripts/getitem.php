<?php
require_once "conn.php";

$item_id = $_POST["item_id"]; 

$qry = "select * from item where item.ItemID = '$item_id';";

$result = mysqli_query($conn, $qry);

$response = array();

$row = mysqli_fetch_array($result);

array_push($response,array("ItemID"=>$row[0],"Seller"=>$row[1],"Title"=>$row[2],
"Descrip"=>$row[3],"image"=>$row[4],"Condition"=>$row[5],"Price"=>$row[6], "location"=>$row[7],
"method"=>$row[8],"postprice"=>$row[9],"ReturnAccepted"=>$row[10],"Postdate"=>$row[11],"Qty"=>$row[12]));

echo json_encode(array("server_response"=>$response));

mysqli_close($conn);
?>